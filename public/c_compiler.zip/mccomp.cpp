#include "llvm/ADT/APFloat.h"
#include "llvm/ADT/Optional.h"
#include "llvm/ADT/STLExtras.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/Verifier.h"
#include "llvm/Support/FileSystem.h"
#include "llvm/Support/Host.h"
#include "llvm/Support/TargetRegistry.h"
#include "llvm/Support/TargetSelect.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Target/TargetMachine.h"
#include "llvm/Target/TargetOptions.h"
#include <algorithm>
#include <cassert>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <map>
#include <memory>
#include <queue>
#include <string.h>
#include <string>
#include <system_error>
#include <utility>
#include <vector>
#include <stack>
#include <exception>
#include <iostream>
#include <fstream>
#include <stdexcept>

using namespace llvm;
using namespace llvm::sys;

FILE *pFile;

//===----------------------------------------------------------------------===//
// Lexer
//===----------------------------------------------------------------------===//

// The lexer returns one of these for known things.
enum TOKEN_TYPE {

  IDENT = -1,        // [a-zA-Z_][a-zA-Z_0-9]*
  ASSIGN = int('='), // '='

  // delimiters
  LBRA = int('{'),  // left brace
  RBRA = int('}'),  // right brace
  LPAR = int('('),  // left parenthesis
  RPAR = int(')'),  // right parenthesis
  SC = int(';'),    // semicolon
  COMMA = int(','), // comma

  // types
  INT_TOK = -2,   // "int"
  VOID_TOK = -3,  // "void"
  FLOAT_TOK = -4, // "float"
  BOOL_TOK = -5,  // "bool"

  // keywords
  EXTERN = -6,  // "extern"
  IF = -7,      // "if"
  ELSE = -8,    // "else"
  WHILE = -9,   // "while"
  RETURN = -10, // "return"
  // TRUE   = -12,     // "true"
  // FALSE   = -13,     // "false"

  // literals
  INT_LIT = -14,   // [0-9]+
  FLOAT_LIT = -15, // [0-9]+.[0-9]+
  BOOL_LIT = -16,  // "true" or "false" key words

  // logical operators
  AND = -17, // "&&"
  OR = -18,  // "||"

  // operators
  PLUS = int('+'),    // addition or unary plus
  MINUS = int('-'),   // substraction or unary negative
  ASTERIX = int('*'), // multiplication
  DIV = int('/'),     // division
  MOD = int('%'),     // modular
  NOT = int('!'),     // unary negation

  // comparison operators
  EQ = -19,      // equal
  NE = -20,      // not equal
  LE = -21,      // less than or equal to
  LT = int('<'), // less than
  GE = -23,      // greater than or equal to
  GT = int('>'), // greater than

  // special tokens
  EOF_TOK = 0, // signal end of file

  // invalid
  INVALID = -100, // signal invalid token

  EPSILON, //empty string

  // non terminals
  arg_list_,      // -98
  arg_list,       // -97
  args,           // -96
  irval,          // -95
  rval_,          // -94
  rval,           // -93
  expr,           // -92
  return_stmt_,   // -91
  return_stmt,    // -90
  else_stmt,      // -89
  if_stmt,        // -88
  while_stmt,     // -87
  expr_stmt,      // -86
  stmt,           // -85
  local_decl,     // -84
  stmt_list,      // -83
  local_decls,    // -82
  block,          // -81
  param,          // -80
  param_list_,    // -79
  param_list,     // -78
  params,         // -77
  fun_decl,       // -76
  var_type,       // -75
  type_spec,      // -74
  var_decl,       // -73
  decl,           // -72
  decl_list_,     // -71
  decl_list,      // -70
  extern_,        // -69
  extern_list_,   // -68
  extern_list,    // -67
  program         // -66
};

// TOKEN struct is used to keep track of information about a token
struct TOKEN {
  int type = -100;
  std::string lexeme;
  int lineNo;
  int columnNo;
};

static std::string IdentifierStr; // Filled in if IDENT
static int IntVal;                // Filled in if INT_LIT
static bool BoolVal;              // Filled in if BOOL_LIT
static float FloatVal;            // Filled in if FLOAT_LIT
static std::string StringVal;     // Filled in if String Literal
static int lineNo, columnNo;

static TOKEN returnTok(std::string lexVal, int tok_type) {
  TOKEN return_tok;
  return_tok.lexeme = lexVal;
  return_tok.type = tok_type;
  return_tok.lineNo = lineNo;
  return_tok.columnNo = columnNo - lexVal.length() - 1;
  return return_tok;
}

// Read file line by line -- or look for \n and if found add 1 to line number
// and reset column number to 0
/// gettok - Return the next token from standard input.
static TOKEN gettok() {

  static int LastChar = ' ';
  static int NextChar = ' ';

  // Skip any whitespace.
  while (isspace(LastChar)) {
    if (LastChar == '\n' || LastChar == '\r') {
      lineNo++;
      columnNo = 1;
    }
    LastChar = getc(pFile);
    columnNo++;
  }

  if (isalpha(LastChar) ||
      (LastChar == '_')) { // identifier: [a-zA-Z_][a-zA-Z_0-9]*
    IdentifierStr = LastChar;
    columnNo++;

    while (isalnum((LastChar = getc(pFile))) || (LastChar == '_')) {
      IdentifierStr += LastChar;
      columnNo++;
    }

    if (IdentifierStr == "int")
      return returnTok("int", INT_TOK);
    if (IdentifierStr == "bool")
      return returnTok("bool", BOOL_TOK);
    if (IdentifierStr == "float")
      return returnTok("float", FLOAT_TOK);
    if (IdentifierStr == "void")
      return returnTok("void", VOID_TOK);
    if (IdentifierStr == "bool")
      return returnTok("bool", BOOL_TOK);
    if (IdentifierStr == "extern")
      return returnTok("extern", EXTERN);
    if (IdentifierStr == "if")
      return returnTok("if", IF);
    if (IdentifierStr == "else")
      return returnTok("else", ELSE);
    if (IdentifierStr == "while")
      return returnTok("while", WHILE);
    if (IdentifierStr == "return")
      return returnTok("return", RETURN);
    if (IdentifierStr == "true") {
      BoolVal = true;
      return returnTok("true", BOOL_LIT);
    }
    if (IdentifierStr == "false") {
      BoolVal = false;
      return returnTok("false", BOOL_LIT);
    }

    return returnTok(IdentifierStr.c_str(), IDENT);
  }

  if (LastChar == '=') {
    NextChar = getc(pFile);
    if (NextChar == '=') { // EQ: ==
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("==", EQ);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("=", ASSIGN);
    }
  }

  if (LastChar == '{') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok("{", LBRA);
  }
  if (LastChar == '}') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok("}", RBRA);
  }
  if (LastChar == '(') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok("(", LPAR);
  }
  if (LastChar == ')') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok(")", RPAR);
  }
  if (LastChar == ';') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok(";", SC);
  }
  if (LastChar == ',') {
    LastChar = getc(pFile);
    columnNo++;
    return returnTok(",", COMMA);
  }

  if (isdigit(LastChar) || LastChar == '.') { // Number: [0-9]+.
    std::string NumStr;

    if (LastChar == '.') { // Floatingpoint Number: .[0-9]+
      do {
        NumStr += LastChar;
        LastChar = getc(pFile);
        columnNo++;
      } while (isdigit(LastChar));

      FloatVal = strtof(NumStr.c_str(), nullptr);
      return returnTok(NumStr, FLOAT_LIT);
    } else {
      do { // Start of Number: [0-9]+
        NumStr += LastChar;
        LastChar = getc(pFile);
        columnNo++;
      } while (isdigit(LastChar));

      if (LastChar == '.') { // Floatingpoint Number: [0-9]+.[0-9]+)
        do {
          NumStr += LastChar;
          LastChar = getc(pFile);
          columnNo++;
        } while (isdigit(LastChar));

        FloatVal = strtof(NumStr.c_str(), nullptr);
        return returnTok(NumStr, FLOAT_LIT);
      } else { // Integer : [0-9]+
        IntVal = strtod(NumStr.c_str(), nullptr);
        return returnTok(NumStr, INT_LIT);
      }
    }
  }

  if (LastChar == '&') {
    NextChar = getc(pFile);
    if (NextChar == '&') { // AND: &&
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("&&", AND);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("&", int('&'));
    }
  }

  if (LastChar == '|') {
    NextChar = getc(pFile);
    if (NextChar == '|') { // OR: ||
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("||", OR);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("|", int('|'));
    }
  }

  if (LastChar == '!') {
    NextChar = getc(pFile);
    if (NextChar == '=') { // NE: !=
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("!=", NE);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("!", NOT);
      ;
    }
  }

  if (LastChar == '<') {
    NextChar = getc(pFile);
    if (NextChar == '=') { // LE: <=
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok("<=", LE);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok("<", LT);
    }
  }

  if (LastChar == '>') {
    NextChar = getc(pFile);
    if (NextChar == '=') { // GE: >=
      LastChar = getc(pFile);
      columnNo += 2;
      return returnTok(">=", GE);
    } else {
      LastChar = NextChar;
      columnNo++;
      return returnTok(">", GT);
    }
  }

  if (LastChar == '/') { // could be division or could be the start of a comment
    LastChar = getc(pFile);
    columnNo++;
    if (LastChar == '/') { // definitely a comment
      do {
        LastChar = getc(pFile);
        columnNo++;
      } while (LastChar != EOF && LastChar != '\n' && LastChar != '\r');

      if (LastChar != EOF)
        return gettok();
    } else
      return returnTok("/", DIV);
  }

  // Check for end of file.  Don't eat the EOF.
  if (LastChar == EOF) {
    columnNo++;
    return returnTok("0", EOF_TOK);
  }

  // Otherwise, just return the character as its ascii value.
  int ThisChar = LastChar;
  std::string s(1, ThisChar);
  LastChar = getc(pFile);
  columnNo++;
  return returnTok(s, int(ThisChar));
}

//===----------------------------------------------------------------------===//
// Parser
//===----------------------------------------------------------------------===//

static bool syntax_valid;              // is CurTok valid syntax in the grammar
static bool sv_out;                    // is input stream a valid program
static bool parser_complete;           // has parser reached EOF
static int indent;                     // indentation level
std::map<int, std::vector<int>> first; // <tok,FIRST(tok)>
static void makeFirst(){ // generates the FIRST sets for the grammar
  first[arg_list_] = {COMMA, EPSILON};
  first[arg_list] = {IDENT};
  first[args] = {IDENT};
  first[irval] = {LPAR, OR, AND, EQ, NE, LE, LT, GE, GT, PLUS, MINUS, ASTERIX, DIV, MOD, EPSILON};
  first[rval_] = {OR, AND, EQ, NE, LE, LT, GE, GT, PLUS, MINUS, ASTERIX, DIV, MOD, EPSILON};
  first[rval] = {IDENT, MINUS, NOT, LPAR, INT_LIT, FLOAT_LIT, BOOL_LIT};
  first[expr] = {IDENT, MINUS, NOT, LPAR, INT_LIT, FLOAT_LIT, BOOL_LIT};
  first[return_stmt_] = {RETURN, SC};
  first[return_stmt] = {RETURN};
  first[else_stmt] = {ELSE, EPSILON};
  first[if_stmt] = {IF};
  first[while_stmt] = {WHILE};
  first[expr_stmt] = {IDENT, SC};
  first[stmt] = {IDENT, SC, LBRA, WHILE, IF, RETURN};
  first[local_decl] = {INT_TOK, FLOAT_TOK, BOOL_TOK};
  first[stmt_list] = {IDENT, SC, LBRA, WHILE, IF, RETURN, EPSILON};
  first[local_decls] = {INT_TOK, FLOAT_TOK, BOOL_TOK, EPSILON};
  first[block] = {LBRA};
  first[param] = {INT_TOK, FLOAT_TOK, BOOL_TOK};
  first[param_list_] = {COMMA, EPSILON};
  first[param_list] = {INT_TOK, FLOAT_TOK, BOOL_TOK};
  first[params] = {VOID_TOK, INT_TOK, FLOAT_TOK, BOOL_TOK, EPSILON};
  first[fun_decl] = {VOID_TOK, INT_TOK, FLOAT_TOK, BOOL_TOK};
  first[var_type] = {INT_TOK, FLOAT_TOK, BOOL_TOK};
  first[type_spec] = {VOID_TOK, INT_TOK, FLOAT_TOK, BOOL_TOK};
  first[var_decl] = {INT_TOK, FLOAT_TOK, BOOL_TOK};
  first[decl] = {VOID_TOK, INT_TOK, FLOAT_TOK, BOOL_TOK};
  first[decl_list_] = {VOID_TOK, INT_TOK, FLOAT_TOK, BOOL_TOK, EPSILON};
  first[decl_list] = {VOID_TOK, INT_TOK, FLOAT_TOK, BOOL_TOK};
  first[extern_] = {EXTERN};
  first[extern_list_] = {EXTERN, EPSILON};
  first[extern_list] = {EXTERN};
  first[program] = {EXTERN, VOID_TOK, INT_TOK, FLOAT_TOK, BOOL_TOK};
}
static bool match(int focus, int word){ // matches start of focus to input word
  if (focus == word) return true; //terminal
  for (int i = 0; i < first[focus].size(); i++){
    if (first[focus][i] == word) return true; //nonterminal
  }
  return false;
}
static bool match(TOKEN focus, TOKEN word){
  return match(focus.type, word.type);
}

static std::string indentStr(){ // returns string indentation for AST
  const int f = 1;
  const std::string c = " |";
  const std::string e = " +-";
  std::string q = "";
  for (int i = 0; i < f * indent - 1; i++) q += c;
  q += e;
  return q;
}
static std::string tokStr(int type){ // takes token type and returns corresponding token string
  switch(type){
    case -2: 
      return "INT";
    case -3:
      return "VOID";
    case -4:
      return "BOOL";
    case -5:
      return "FLOAT";
    case int('+'):
      return "(+)";
    case int('-'):
      return "(-)";
    case int('*'):
      return "(*)";
    case int('/'):
      return "(/)";
    case int('%'):
      return "(%)";
    case int('!'):
      return "NOT";
    case -19:
      return "(==)";
    case -20:
      return "(!=)";
    case -21:
      return "(<=)";
    case int('<'):
      return "(<)";
    case -23:
      return "(>=)";
    case int('>'):
      return ">";
    default:
      return "Tok(" + std::to_string(type) + ")";
  }
}

/// CurTok/getNextToken - Provide a simple token buffer.  CurTok is the current
/// token the parser is looking at.  getNextToken reads another token from the
/// lexer and updates CurTok with its results.
static TOKEN CurTok;
static std::deque<TOKEN> tok_buffer;

static TOKEN getNextToken() {

  if (tok_buffer.size() == 0)
    tok_buffer.push_back(gettok());

  TOKEN temp = tok_buffer.front();
  tok_buffer.pop_front();
  if (!syntax_valid){
    sv_out = false;
    fprintf(stderr, "Syntax error:\n  Token: %s\n  Type: %d\n  Line: %d\n  Col: %d\n",
      CurTok.lexeme.c_str(), CurTok.type, lineNo, columnNo);
      syntax_valid = true;
  } 
  //if (syntax_valid) fprintf(stderr, "*");
  //fprintf(stderr, "new token: %s\n", temp.lexeme.c_str());
  return CurTok = temp;
}

static void putBackToken(TOKEN tok) { tok_buffer.push_front(tok); }

static bool match(int focus){ 
  return match(focus, CurTok.type);
}
static bool lookahead(int focus, int k){ // looks ahead k symbols
  bool retval;
  std::stack<TOKEN> temp;
  for (int i = 0; i < k; i++){
    temp.push(CurTok);
    getNextToken();
  }
  retval = match(focus);
  putBackToken(CurTok);
  for (int i = 0; i < k; i++){
    putBackToken(temp.top());
    temp.pop();
  }
  getNextToken();
  return retval;
}

//===----------------------------------------------------------------------===//
// AST nodes
//===----------------------------------------------------------------------===//


/// ASTnode - Base class for all AST nodes.

class ASTnode {
  public:
  virtual ~ASTnode() {} // virtual not pure
  virtual Value *codegen() = 0; // pure virtual
  virtual std::string to_string() const;
};
class VarASTnode : public ASTnode {
  std::string _ident;
  public: VarASTnode(){
    _ident = CurTok.lexeme;
  };
  virtual ~VarASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
  virtual std::string name() {return _ident;}
};
class FuncASTnode : public ASTnode {
  std::string _ident;
  std::vector<std::unique_ptr<ASTnode>> _args;
  public: FuncASTnode();
  virtual ~FuncASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class IntASTnode : public ASTnode {
  int Val;
  TOKEN Tok;
  std::string Name;
  public: IntASTnode(){
    Val = IntVal;
    Tok = CurTok;
  }
  virtual ~IntASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override{
    return std::to_string(Val);
  }
};
class FloatASTnode : public ASTnode {
  float Val;
  TOKEN Tok;
  public: FloatASTnode(){
    Val = FloatVal;
    Tok = CurTok;
  }
  virtual ~FloatASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override{
    return std::to_string(Val);
  }
};
class BoolASTnode : public ASTnode {
  bool Val;
  TOKEN Tok;
  public: BoolASTnode(){
    Val = BoolVal;
    Tok = CurTok;
  }
  virtual ~BoolASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override{
    return std::to_string(Val);
  }
};
class ExprASTnode : public ASTnode {
  std::unique_ptr<VarASTnode> _var;
  std::unique_ptr<ExprASTnode> _expr;
  std::unique_ptr<ASTnode> _rval;
  public: ExprASTnode();
  virtual ~ExprASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class Rval_ASTnode;
class RvalASTnode : public ASTnode {
  int _neg; //TOKEN_TYPE
  std::unique_ptr<RvalASTnode> _rval; //negated rval AST node
  std::unique_ptr<ExprASTnode> _in_par; //expr AST node in parentheses
  std::unique_ptr<ASTnode> _lit; //literal AST node
  std::unique_ptr<VarASTnode> _var; //variable name
  std::unique_ptr<FuncASTnode> _func; //function call
  std::unique_ptr<Rval_ASTnode> _next; //rval_
  public: RvalASTnode();
  virtual ~RvalASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class Rval_ASTnode : public ASTnode {
  int _op; //TOKEN_TYPE
  std::unique_ptr<RvalASTnode> _next;
  public: Rval_ASTnode();
  virtual ~Rval_ASTnode();
  virtual Value *codegen() override;
  virtual Value *codegen(Value *L);
  virtual std::string to_string() const override;
};
class LocalDeclASTnode : public ASTnode {
  int _var_type; //TOKEN_TYPE
  std::unique_ptr<VarASTnode> _var;
  public: LocalDeclASTnode();
  virtual ~LocalDeclASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class StmtASTnode : public ASTnode {};
class BlockASTnode : public StmtASTnode {
  std::vector<std::unique_ptr<LocalDeclASTnode>> _local_decls;
  std::vector<std::unique_ptr<StmtASTnode>> _stmt_list;
  public: BlockASTnode();
  virtual ~BlockASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class ParamASTnode : public ASTnode {
  int _var_type;
  std::unique_ptr<VarASTnode> _var;
  public: ParamASTnode();
  virtual ~ParamASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
  virtual std::string name() {return _var->name();}
  virtual int type() {return _var_type;}
};
class ReturnStmtASTnode : public StmtASTnode {
  std::unique_ptr<ExprASTnode> _expr; //retval
  public: ReturnStmtASTnode();
  virtual ~ReturnStmtASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class IfStmtASTnode : public StmtASTnode {
  std::unique_ptr<ExprASTnode> _cond;
  std::unique_ptr<BlockASTnode> _then;
  std::unique_ptr<BlockASTnode> _else;
  public: IfStmtASTnode();
  virtual ~IfStmtASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class WhileStmtASTnode : public StmtASTnode {
  std::unique_ptr<ExprASTnode> _cond;
  std::unique_ptr<StmtASTnode> _loop;
  public: WhileStmtASTnode();
  virtual ~WhileStmtASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class ExprStmtASTnode : public StmtASTnode {
  std::unique_ptr<ExprASTnode> _expr;
  public: ExprStmtASTnode();
  virtual ~ExprStmtASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class DeclASTnode {
  public:
  virtual ~DeclASTnode() {}
  virtual Function *codegen() = 0;
  virtual std::string to_string() const;
};
class FunDeclASTnode : public DeclASTnode {
  int _type_spec;
  std::unique_ptr<VarASTnode> _var;
  bool _is_void;
  std::vector<std::unique_ptr<ParamASTnode>> _params;
  std::unique_ptr<BlockASTnode> _block;
  public: FunDeclASTnode();
  virtual ~FunDeclASTnode();
  virtual Function *codegen() override;
  virtual std::string to_string() const override;
};
class VarDeclASTnode : public DeclASTnode {
  int _var_type;
  std::unique_ptr<VarASTnode> _var;
  public: VarDeclASTnode();
  virtual ~VarDeclASTnode();
  virtual Function *codegen() override;
  virtual std::string to_string() const override;
};
class ExternASTnode : public ASTnode {
  int _type_spec;
  std::unique_ptr<VarASTnode> _var;
  bool _is_void;
  std::vector<std::unique_ptr<ParamASTnode>> _params;
  public: ExternASTnode();
  virtual ~ExternASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override;
};
class ProgramASTnode : public ASTnode {
  std::vector<std::unique_ptr<ExternASTnode>> _extern_list;
  std::vector<std::unique_ptr<DeclASTnode>> _decl_list;
  public: ProgramASTnode();
  virtual ~ProgramASTnode();
  virtual Value *codegen() override;
  virtual std::string to_string() const override; 
};

// Class destructors
VarASTnode::~VarASTnode() {}
FuncASTnode::~FuncASTnode() {}
IntASTnode::~IntASTnode() {}
FloatASTnode::~FloatASTnode() {}
BoolASTnode::~BoolASTnode() {}
ExprASTnode::~ExprASTnode() {}
RvalASTnode::~RvalASTnode() {}
Rval_ASTnode::~Rval_ASTnode() {}
LocalDeclASTnode::~LocalDeclASTnode() {}
BlockASTnode::~BlockASTnode() {}
ParamASTnode::~ParamASTnode() {}
ReturnStmtASTnode::~ReturnStmtASTnode() {}
IfStmtASTnode::~IfStmtASTnode() {}
WhileStmtASTnode::~WhileStmtASTnode() {}
ExprStmtASTnode::~ExprStmtASTnode() {}
FunDeclASTnode::~FunDeclASTnode() {}
VarDeclASTnode::~VarDeclASTnode() {}
ExternASTnode::~ExternASTnode() {}
ProgramASTnode::~ProgramASTnode() {}

//===----------------------------------------------------------------------===//
// Recursive Descent Parser - Function call for each production
//===----------------------------------------------------------------------===//

static void printSuccess(){ // indicates success at end of parse
  std::string ln = "#---------------------------------#";
  fprintf(stderr, "\n%s\n Parsing Successful. Printing AST:\n%s\n\n", ln.c_str(), ln.c_str());
}
static void printErr(){ // indicates parse failure
  fprintf(stderr, "Program contains invalid syntax. Parse not successful\n");
}

/*
    Each method makes a new AST node and returns a pointer to it.
    The AST nodes are derived from the parser grammar.
*/
static std::unique_ptr<VarASTnode> parseVar(){ // parse a variable identifier
  std::unique_ptr<VarASTnode> _var;
  _var = std::make_unique<VarASTnode>();
  getNextToken();
  return std::move(_var);
}
static std::unique_ptr<FuncASTnode> parseFunc(){ // parse a function call
  std::unique_ptr<FuncASTnode> _func;
  _func = std::make_unique<FuncASTnode>();
  return std::move(_func);
}
static std::unique_ptr<ASTnode> parseLit(){ // parse int, float and bool literals
  std::unique_ptr<ASTnode> _lit;
  if (match(INT_LIT, CurTok.type)) _lit = std::make_unique<IntASTnode>();
  else if (match(FLOAT_LIT, CurTok.type)) _lit = std::make_unique<FloatASTnode>();
  else if (match(BOOL_LIT, CurTok.type)) _lit = std::make_unique<BoolASTnode>();
  else syntax_valid = false;
  getNextToken();
  return std::move(_lit);
}
static std::unique_ptr<Rval_ASTnode> parseRval_(){ // parse rval' (see grammar)
  std::unique_ptr<Rval_ASTnode> _rval_;
  _rval_ = std::make_unique<Rval_ASTnode>();
  return std::move(_rval_);
}
static std::unique_ptr<RvalASTnode> parseRval(){
  std::unique_ptr<RvalASTnode> _rval;
  _rval = std::make_unique<RvalASTnode>();
  return std::move(_rval);
}
static std::unique_ptr<ExprASTnode> parseExpr(){
  std::unique_ptr<ExprASTnode> _expr;
  _expr = std::make_unique<ExprASTnode>();
  return std::move(_expr);
}
static std::unique_ptr<ReturnStmtASTnode> parseReturnStmt(){
  std::unique_ptr<ReturnStmtASTnode> _return_stmt;
  _return_stmt = std::make_unique<ReturnStmtASTnode>();
  return std::move(_return_stmt);
}
static std::unique_ptr<WhileStmtASTnode> parseWhileStmt(){
  std::unique_ptr<WhileStmtASTnode> _while_stmt;
  _while_stmt = std::make_unique<WhileStmtASTnode>();
  return std::move(_while_stmt);
}
static std::unique_ptr<IfStmtASTnode> parseIfStmt(){
  std::unique_ptr<IfStmtASTnode> _if_stmt;
  _if_stmt = std::make_unique<IfStmtASTnode>();
  return std::move(_if_stmt);
}
static std::unique_ptr<ExprStmtASTnode> parseExprStmt(){
  std::unique_ptr<ExprStmtASTnode> _expr_stmt;
  _expr_stmt = std::make_unique<ExprStmtASTnode>();
  return std::move(_expr_stmt);
}
static std::unique_ptr<BlockASTnode> parseBlock(){
  std::unique_ptr<BlockASTnode> _block;
  _block = std::make_unique<BlockASTnode>();
  return std::move(_block);
}
static std::unique_ptr<StmtASTnode> parseStmt(){
  std::unique_ptr<StmtASTnode> _stmt;
  if (match(expr_stmt, CurTok.type)) _stmt = parseExprStmt();
  else if (match(block, CurTok.type)) _stmt = parseBlock();
  else if (match(if_stmt, CurTok.type)) _stmt = parseIfStmt();
  else if (match(while_stmt, CurTok.type)) _stmt = parseWhileStmt();
  else if (match(return_stmt, CurTok.type)) _stmt = parseReturnStmt();
  else syntax_valid = false;
  return std::move(_stmt);
}
static std::unique_ptr<LocalDeclASTnode> parseLocalDecl(){
  std::unique_ptr<LocalDeclASTnode> _local_decl;
  _local_decl = std::make_unique<LocalDeclASTnode>();
  return std::move(_local_decl);
}
static std::unique_ptr<ParamASTnode> parseParam(){
  std::unique_ptr<ParamASTnode> _param;
  _param = std::make_unique<ParamASTnode>();
  return std::move(_param);
}
static std::unique_ptr<FunDeclASTnode> parseFunDecl(){
  std::unique_ptr<FunDeclASTnode> _fun_decl;
  _fun_decl = std::make_unique<FunDeclASTnode>();
  return std::move(_fun_decl);
}
static std::unique_ptr<VarDeclASTnode> parseVarDecl(){
  std::unique_ptr<VarDeclASTnode> _var_decl;
  _var_decl = std::make_unique<VarDeclASTnode>();
  return std::move(_var_decl);
}
static std::unique_ptr<DeclASTnode> parseDecl(){
  if (lookahead(LPAR, 2)) return parseFunDecl();
  else return parseVarDecl();
}
static std::unique_ptr<ExternASTnode> parseExtern(){
  std::unique_ptr<ExternASTnode> _extern;
  _extern = std::make_unique<ExternASTnode>();
  return std::move(_extern);
}
static std::unique_ptr<ProgramASTnode> parseProgram(){
  std::unique_ptr<ProgramASTnode> _program;
  _program = std::make_unique<ProgramASTnode>();
  return std::move(_program);
}
static void parser(){ // main parser loop
  syntax_valid = true; // checks if CurTok follows syntax rules
  sv_out = true; // checks if the whole program follows syntax rules
  parser_complete = false; // checks if EOF is reached
  getNextToken();
  std::unique_ptr<ProgramASTnode> _program;
  _program = parseProgram(); // returns a pointer to the root AST node
  if (match(EOF_TOK, CurTok.type)) parser_complete = true;
  if (sv_out && syntax_valid && parser_complete){
    printSuccess();
    fprintf(stderr, "%s\n", _program->to_string().c_str());
    _program->codegen();
  }
  else printErr();
  return;
}

/*
    Constructors for the AST nodes.
    Each constructor uses the grammar rules to parse a section of the input.
*/
FuncASTnode::FuncASTnode(){
  if (match(IDENT, CurTok.type)) _ident = CurTok.lexeme;
  else syntax_valid = false;
  getNextToken();
  if (!match(LPAR, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (match(expr, CurTok.type)){
    _args.push_back(parseExpr());
    while(match(COMMA, CurTok.type)){
      getNextToken();
      if (match(expr, CurTok.type)) _args.push_back(parseExpr());
      else syntax_valid = false;
    }
  }
  if (!match(RPAR, CurTok.type)) syntax_valid = false;
  getNextToken();
}
ExprASTnode::ExprASTnode(){
  if (lookahead(ASSIGN, 1)){
    _var = parseVar();
    if (!match(ASSIGN, CurTok.type)) syntax_valid = false;
    getNextToken();
    if (match(expr, CurTok.type)) _expr = parseExpr();
    else syntax_valid = false;
  }
  else{
    if (match(rval, CurTok.type)) _rval = parseRval();
    else syntax_valid = false;
  }
}
Rval_ASTnode::Rval_ASTnode(){
  if (match(OR, CurTok.type) || match(AND, CurTok.type)
    || match(EQ, CurTok.type) || match(NE, CurTok.type)
    || match(LE, CurTok.type) || match(LT, CurTok.type)
    || match(GE, CurTok.type) || match(GT, CurTok.type)
    || match(PLUS, CurTok.type) || match(MINUS, CurTok.type)
    || match(ASTERIX, CurTok.type) || match(DIV, CurTok.type) 
    || match(MOD, CurTok.type)){
    _op = CurTok.type;
    getNextToken();
    _next = parseRval();
  }
}
RvalASTnode::RvalASTnode(){
  if (match(MINUS, CurTok.type) || match(NOT, CurTok.type)){
    _neg = CurTok.type;
    getNextToken();
    if (match(rval, CurTok.type)) _rval = parseRval();
    else syntax_valid = false;
  }
  else if (match(LPAR, CurTok.type)){
    getNextToken();
    if (match(expr, CurTok.type)) _in_par = parseExpr();
    else syntax_valid = false;
    if (!match(RPAR, CurTok.type)) syntax_valid = false;
    getNextToken();
  }
  else if (match(IDENT, CurTok.type)){
    if (lookahead(LPAR, 1)) _func = parseFunc();
    else _var = parseVar();
  }
  else if (match(INT_LIT, CurTok.type) || match(FLOAT_LIT, CurTok.type)
    || match(BOOL_LIT, CurTok.type)) _lit = parseLit();
  else syntax_valid = false;
  _next = parseRval_();
}
ReturnStmtASTnode::ReturnStmtASTnode(){
  if (!match(RETURN, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (match(expr, CurTok.type)) _expr = parseExpr();
  if (!match(SC, CurTok.type)) syntax_valid = false;
  getNextToken();
}
IfStmtASTnode::IfStmtASTnode(){
  if (!match(IF, CurTok.type)) syntax_valid = false; // "if"
  getNextToken();
  if (!match(LPAR, CurTok.type)) syntax_valid = false; // "("
  getNextToken();
  if (match(expr, CurTok.type)) _cond = parseExpr(); // expr
  else syntax_valid = false;
  if (!match(RPAR, CurTok.type)) syntax_valid = false; // ")"
  getNextToken();
  if (match(block, CurTok.type)) _then = parseBlock(); // block
  else syntax_valid = false;
  if (match(ELSE, CurTok.type)){ // "else"
    getNextToken();
    if (match(block, CurTok.type)) _else = parseBlock(); // block
    else syntax_valid = false;
  }// | epsilon
}
WhileStmtASTnode::WhileStmtASTnode(){
  if (!match(WHILE, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (!match(LPAR, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (match(expr, CurTok.type)) _cond = parseExpr();
  else syntax_valid = false;
  if (!match(RPAR, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (match(stmt, CurTok.type)) _loop = parseStmt();
}
ExprStmtASTnode::ExprStmtASTnode(){
  if (match(expr, CurTok.type)){
    _expr = parseExpr();
  }
  if (!match(SC, CurTok.type)) syntax_valid = false;
  getNextToken();
}
LocalDeclASTnode::LocalDeclASTnode(){
  if (match(var_type, CurTok.type)) _var_type = CurTok.type;
  else syntax_valid = false;
  getNextToken();
  if (match(IDENT, CurTok.type)) _var = parseVar();
  else syntax_valid = false;
  if (!match(SC, CurTok.type)) syntax_valid = false;
  getNextToken();
}
BlockASTnode::BlockASTnode(){
  if (!match(LBRA, CurTok.type)) syntax_valid = false;
  getNextToken();
  while(match(local_decl, CurTok.type)){
    _local_decls.push_back(parseLocalDecl());
  }
  while(match(stmt, CurTok.type)){
    _stmt_list.push_back(parseStmt());
  }
  if (!match(RBRA, CurTok.type)) syntax_valid = false;
  getNextToken();
}
ParamASTnode::ParamASTnode(){
  if (match(var_type, CurTok.type)) _var_type = CurTok.type;
  else syntax_valid = false;
  getNextToken();
  if (match(IDENT, CurTok.type)) _var = parseVar();
  else syntax_valid = false;
}
FunDeclASTnode::FunDeclASTnode(){
  if (match(type_spec, CurTok.type)) _type_spec = CurTok.type;
  else syntax_valid = false;
  getNextToken();
  if (match(IDENT, CurTok.type)) _var = parseVar();
  else syntax_valid = false;
  if (!match(LPAR, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (match(VOID_TOK, CurTok.type)){ _is_void = true; getNextToken(); }
  else if (match(param, CurTok.type)){
    _params.push_back(parseParam());
    while(match(COMMA, CurTok.type)){
      getNextToken();
      if (match(param, CurTok.type)) _params.push_back(parseParam());
      else syntax_valid = false;
    }
  }
  if (!match(RPAR, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (match(block, CurTok.type)) _block = parseBlock();
  else syntax_valid = false;
}
VarDeclASTnode::VarDeclASTnode(){
  if (match(var_type, CurTok.type)) _var_type = CurTok.type;
  else syntax_valid = false;
  getNextToken();
  if (match(IDENT, CurTok.type)) _var = parseVar();
  else syntax_valid = false;
  if (!match(SC, CurTok.type)) syntax_valid = false;
  getNextToken();
}
ExternASTnode::ExternASTnode(){
  if (!match(EXTERN, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (match(type_spec, CurTok.type)) _type_spec = CurTok.type;
  else syntax_valid = false;
  getNextToken();
  if (match(IDENT, CurTok.type)) _var = parseVar();
  else syntax_valid = false;
  if (!match(LPAR, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (match(VOID_TOK, CurTok.type)){ _is_void = true; getNextToken(); }
  else if (match(param, CurTok.type)){
    _params.push_back(parseParam());
    while(match(COMMA, CurTok.type)){
      getNextToken();
      if (match(param, CurTok.type)) _params.push_back(parseParam());
      else syntax_valid = false;
    }
  }
  if (!match(RPAR, CurTok.type)) syntax_valid = false;
  getNextToken();
  if (!match(SC, CurTok.type)) syntax_valid = false;
  getNextToken();
}
ProgramASTnode::ProgramASTnode(){
  while (match(extern_, CurTok.type)){
    _extern_list.push_back(parseExtern());
  }
  if (match(decl, CurTok.type)) _decl_list.push_back(parseDecl());
  else {syntax_valid = false; fprintf(stderr, "%d\n", CurTok.type);}
  while (match(decl, CurTok.type)) {
    _decl_list.push_back(parseDecl());
  }
}

//===----------------------------------------------------------------------===//
// Code Generation
//===----------------------------------------------------------------------===//

static LLVMContext TheContext;
static IRBuilder<> Builder(TheContext);
static std::unique_ptr<Module> TheModule;
static std::map<std::string, AllocaInst *> NamedValues;
static std::map<std::string, Value *> GlobalVars;

std::unique_ptr<ASTnode> LogError(std::string str) { // print error message
  fprintf(stderr, "Error: %s\n", str.c_str());
  return nullptr;
}
Value *LogErrorV(std::string str){
  LogError(str);
  return nullptr;
}
Type *LogErrorT(std::string str){
  LogError(str);
  return nullptr;
}
static AllocaInst *CreateEntryBlockAlloca(Function *TheFunction, const std::string &VarName, Type *T) {
  IRBuilder<> TmpB(&TheFunction->getEntryBlock(), TheFunction->getEntryBlock().begin());
  return TmpB.CreateAlloca(T, 0, VarName.c_str());
}
static AllocaInst *CreateEntryBlockAlloca(Function *TheFunction, const std::string &VarName) {
  return CreateEntryBlockAlloca(TheFunction, VarName, Type::getDoubleTy(TheContext));
}
static GlobalVariable *CreateGVar(const std::string &VarName, Type *T) { // create global variable
  TheModule->getOrInsertGlobal(VarName, T);
  GlobalVariable *G = TheModule->getNamedGlobal(VarName);
  G->setLinkage(GlobalValue::CommonLinkage);
  return G;
}
Type *getTokType(int n){ // takes TOKEN_TYPE as int and returns LLVM Type as required
  switch(n){
    case INT_TOK: return Type::getInt32Ty(TheContext);
    case FLOAT_TOK: return Type::getDoubleTy(TheContext);
    case BOOL_TOK: return Type::getInt1Ty(TheContext);
    default: return LogErrorT("Invalid type");
  }
}
CmpInst::Predicate getICmpInst(int tok){ // comparators for integers/bools
  switch(tok){ 
    case EQ: return CmpInst::ICMP_EQ;
    case NE: return CmpInst::ICMP_NE;
    case LE: return CmpInst::ICMP_SLE;
    case LT: return CmpInst::ICMP_SLT;
    case GE: return CmpInst::ICMP_SGE;
    case GT: return CmpInst::ICMP_SGT;
    default: return CmpInst::BAD_ICMP_PREDICATE;
  }
}
CmpInst::Predicate getFCmpInst(int tok){ // comparators for floats
  switch(tok){ 
    case EQ: return CmpInst::FCMP_UEQ;
    case NE: return CmpInst::FCMP_UNE;
    case LE: return CmpInst::FCMP_ULE;
    case LT: return CmpInst::FCMP_ULT;
    case GE: return CmpInst::FCMP_UGE;
    case GT: return CmpInst::FCMP_UGT;
    default: return CmpInst::BAD_ICMP_PREDICATE;
  }
}
Value *getOpValFP(int op, Value *L, Value *R){ // handles floating point numbers
  switch(op){
    case PLUS: return Builder.CreateFAdd(L, R, "addtmp");
    case MINUS: return Builder.CreateFSub(L, R, "subtmp");
    case ASTERIX: return Builder.CreateFMul(L, R, "multmp");
    case DIV: return Builder.CreateFDiv(L, R, "divtmp");
    case EQ: case NE: case LE: case LT: case GE: case GT:
      return Builder.CreateFCmp(getFCmpInst(op), L, R, "cmptmp");
    default: return LogErrorV("Invalid binary operator");
  }
}
Value *getOpValSI(int op, Value *L, Value *R){ // handles signed integers
  switch(op){
    case PLUS: return Builder.CreateNSWAdd(L, R, "addtmp");
    case MINUS: return Builder.CreateNSWSub(L, R, "subtmp");
    case ASTERIX: return Builder.CreateNSWMul(L, R, "multmp");
    case DIV: return Builder.CreateSDiv(L, R, "divtmp");
    case EQ: case NE: case LE: case LT: case GE: case GT:
      return Builder.CreateICmp(getICmpInst(op), L, R, "cmptmp");
    default: return LogErrorV("Invalid binary operator");
  }
}
Value *getOpVal(int op, Value *L, Value *R){ // returns value of binary operation
  if (L->getType() == getTokType(FLOAT_TOK)) return getOpValFP(op, L, R);
  return getOpValSI(op, L, R);
}
Value *getInitVal(int type){ // returns an initial value for a global variable
  switch (type){
    case INT_TOK: return ConstantInt::get(Type::getInt32Ty(TheContext), 0, true);
    case FLOAT_TOK: return ConstantFP::get(TheContext, APFloat((double)0.0));
    case BOOL_TOK: return ConstantInt::get(Type::getInt1Ty(TheContext), 0, true);
    default: return LogErrorV("Invalid data type for global variable");
  }
}

Value *VarASTnode::codegen(){
  Value *V = NamedValues[_ident]; // retrieve local variable value
  if (V) return Builder.CreateLoad(V, _ident.c_str());
  V = GlobalVars[_ident]; // retrieve global variable value
  if (!V) return LogErrorV("Unknown variable name \"" + _ident + "\"");
  Builder.CreateLoad(TheModule->getNamedGlobal(_ident));
  return V;
}
Value *FuncASTnode::codegen(){
  Function *Fn = TheModule->getFunction(_ident); // retrieve function from module
  if (!Fn) return LogErrorV("Unknown function referenced");
  if (Fn->arg_size() != _args.size()) return LogErrorV("Incorrect # arguments passed");
  std::vector<Value *> ArgsV;
  for (int i = 0; i < _args.size(); i++){ // generate function arguments
    ArgsV.push_back(_args[i]->codegen());
    if (!ArgsV.back()) return nullptr;
  }
  return Builder.CreateCall(Fn, ArgsV, "calltmp");
}
Value *IntASTnode::codegen(){ // gets the IR of an int literal
  return ConstantInt::get(Type::getInt32Ty(TheContext), Val, true);
}
Value *FloatASTnode::codegen(){ // gets the IR of a float literal
  return ConstantFP::get(TheContext, APFloat((double)Val));
}
Value *BoolASTnode::codegen(){ // gets the IR of a bool literal (as a 1bit int)
  return ConstantInt::get(Type::getInt1Ty(TheContext), Val, true);
}
Value *ExprASTnode::codegen(){
  /* Handling expr::= rval */
  if (_rval) return _rval->codegen(); // return the value of the expression
  Function *TheFunction = Builder.GetInsertBlock()->getParent();
  /* End of rval handling */

  /* Handling expr::= IDENT "=" expr */
  Value *Val;
  Value *Var;
  Val = _expr->codegen(); // get the RHS of the assignment
  if (!Val) return nullptr;
  if (NamedValues.find(_var->name()) == NamedValues.end()){ // check variable name is in scope
    if (GlobalVars.find(_var->name()) == GlobalVars.end()){
      return LogErrorV("No variable \"" + _var->name() + "\" exists in current scope");
    }
    Var = GlobalVars[_var->name()]; // get the value of the global variable
    if (Var->getType() != Val->getType()){ // checks data type of LHS and RHS
      return LogErrorV("Incorrect type for variable \"" + _var->name() + "\"");
    }
  }
  else{
    Var = NamedValues[_var->name()]; // get the value of the local variable
    if (Var->getType() != Val->getType()->getPointerTo()){ // checks data type of LHS and RHS
      return LogErrorV("Incorrect type for variable \"" + _var->name() + "\"");
    }
  }
  Builder.CreateStore(Val, Var); // assigns RHS to the variable
  /* End of expr handling */
  return Val;
}
Value *RvalASTnode::codegen(){
  Value *L; // LHS
  if (_lit) L = _lit->codegen(); // L is a literal
  else if (_var) L = _var->codegen(); // L is a variable name
  else if (_rval){ // L is negated/negative
    L = _rval->codegen();
    if (_neg == MINUS){ // if L starts with a minus symbol
      if (L->getType() == getTokType(FLOAT_TOK)) L = Builder.CreateFNeg(L, "negtmp");
      else if (L->getType() == getTokType(INT_TOK)) L = Builder.CreateNeg(L, "negtmp");
      else return LogErrorV("Unary operator applied to invalid type");
    }
    else if (_neg == NOT){ // if L starts with a logical NOT symbol
      if (L->getType() == getTokType(BOOL_TOK)) L = Builder.CreateNot(L, "nottmp");
      else return LogErrorV("Unary operator applied to invalid type");
    }
    else return LogErrorV("Invalid unary operator");
  }
  else if (_in_par) L = _in_par->codegen(); // L is in parentheses
  else if (_func) L = _func->codegen(); // L is a function
  return _next->codegen(L); // applies value to the right
}
Value *Rval_ASTnode::codegen(){
  return nullptr; // rval' is never leftmost of an expression so this can stay empty
}
Value *Rval_ASTnode::codegen(Value *L){
  if (_next){ // if the node is internal (i.e. not empty)
    Value *R = _next->codegen(); // the RHS of the operation
    return getOpVal(_op, L, R);
  }
  return L; // if the node is a leaf, we just return the initial value
}
Value *ReturnStmtASTnode::codegen(){
  Function *TheFunction = Builder.GetInsertBlock()->getParent();
  if (Value *R = _expr->codegen()){
    if (R->getType() != TheFunction->getReturnType()){ // check the return type is correct
      return LogErrorV("Incorrect return type for function");
    }
    Builder.CreateRet(R);
    return R;
  }
  return nullptr;
}
Value *IfStmtASTnode::codegen(){
  Function *TheFunction = Builder.GetInsertBlock()->getParent();
  BasicBlock *ThenBB = BasicBlock::Create(TheContext, "then", TheFunction);
  BasicBlock *ElseBB = BasicBlock::Create(TheContext, "else");
  BasicBlock *MergeBB = BasicBlock::Create(TheContext, "ifcont");
  /* If Condition */
  Value *CondV = _cond->codegen();
  if (!CondV) return nullptr;
  Builder.CreateCondBr(CondV, ThenBB, ElseBB);
  /* End of If Condition */
  
  /* Then Block */
  Builder.SetInsertPoint(ThenBB);
  Value *ThenV = _then->codegen();
  Builder.CreateBr(MergeBB);
  ThenBB = Builder.GetInsertBlock();
  /* End of Then Block */
  
  /* Else Block */
  if (_else){
    TheFunction->getBasicBlockList().push_back(ElseBB);
    Builder.SetInsertPoint(ElseBB);
    Value *ElseV = _else->codegen();
    Builder.CreateBr(MergeBB);
    ElseBB = Builder.GetInsertBlock();
  }
  /* End of Else Block */

  /* Merge (after If statement is finished) */
  TheFunction->getBasicBlockList().push_back(MergeBB);
  Builder.SetInsertPoint(MergeBB);
  /* End of Merge  */
  return nullptr;
}
Value *WhileStmtASTnode::codegen(){
  Function *TheFunction = Builder.GetInsertBlock()->getParent();
  BasicBlock *CondBB = BasicBlock::Create(TheContext, "while", TheFunction);
  BasicBlock *LoopBB = BasicBlock::Create(TheContext, "loop");
  BasicBlock *AfterBB = BasicBlock::Create(TheContext, "endwhile");
  /* While Condition */
  Builder.CreateBr(CondBB);
  Builder.SetInsertPoint(CondBB);
  Value *CondV = _cond->codegen();
  Builder.CreateCondBr(CondV, LoopBB, AfterBB);
  CondBB = Builder.GetInsertBlock();
  /* End of While Condition */

  /* Loop Block */
  TheFunction->getBasicBlockList().push_back(LoopBB);
  Builder.SetInsertPoint(LoopBB);
  Value *LoopV = _loop->codegen();
  Builder.CreateCondBr(CondV, CondBB, AfterBB);
  LoopBB = Builder.GetInsertBlock();
  /* End of Loop Block */

  /* After Block */
  TheFunction->getBasicBlockList().push_back(AfterBB);
  Builder.SetInsertPoint(AfterBB);
  /* End of After Block */
  return nullptr;
}
Value *ExprStmtASTnode::codegen(){
  return _expr->codegen();
}
Value *LocalDeclASTnode::codegen(){ // local variable declaration
  Function *TheFunction = Builder.GetInsertBlock()->getParent();
  AllocaInst *Alloca = CreateEntryBlockAlloca(TheFunction, _var->name(), getTokType(_var_type));
  NamedValues[_var->name()] = Alloca;
  return nullptr;
}
Value *BlockASTnode::codegen(){
  for (int i = 0; i < _local_decls.size(); i++){
    _local_decls[i]->codegen();
  }
  for (int j = 0; j < _stmt_list.size(); j++){
    _stmt_list[j]->codegen();
  }
  return nullptr;
}
Value *ParamASTnode::codegen(){
  return nullptr; // we never call this function (with more time would remove from the AST)
}
Function *FunDeclASTnode::codegen(){
  /* Function Header */
  std::vector<Type*> Types;
  for (int i = 0; i < _params.size(); i++){ // getting the type of each parameter
    Types.push_back(getTokType(_params[i]->type()));
  }
  FunctionType *FT = FunctionType::get(getTokType(_type_spec), Types, false); // defining the function type
  Function *TheFunction = Function::Create(FT, Function::ExternalLinkage, _var->name(), TheModule.get());
  int i = 0;
  for (auto &A : TheFunction->args()) A.setName(_params[i++]->name()); // setting the argument names
  /*End of Function Header*/

  /* Function Body */
  if (!TheFunction) return nullptr;
  if (!TheFunction->empty()) return (Function*)LogErrorV("Function can't be redefined");
  BasicBlock *BB = BasicBlock::Create(TheContext, "entry", TheFunction);
  Builder.SetInsertPoint(BB);
  NamedValues.clear();
  for (auto &A : TheFunction->args()){ // putting the arguments into scope
    AllocaInst *Alloca = CreateEntryBlockAlloca(TheFunction, A.getName(), A.getType());
    Builder.CreateStore(&A, Alloca);
    NamedValues[A.getName()] = Alloca;
  }
  _block->codegen(); // generating the code for the function body
  verifyFunction(*TheFunction);
  /* End of Function Body */
  return TheFunction;
}
Function *VarDeclASTnode::codegen(){ // declaring a global variable
  GlobalVariable *Var = CreateGVar(_var->name(), getTokType(_var_type));
  GlobalVars[_var->name()] = getInitVal(_var_type);
  return nullptr;
}
Value *ExternASTnode::codegen(){
  std::vector<Type*> Types;
  for (int i = 0; i < _params.size(); i++){ // get the type of the parameters
    Types.push_back(getTokType(_params[i]->type()));
  }
  FunctionType *FT = FunctionType::get(getTokType(_type_spec), Types, false); // function signature
  Function *TheFunction = Function::Create(FT, Function::ExternalLinkage, _var->name(), TheModule.get());
  int i = 0;
  for (auto &A : TheFunction->args()) A.setName(_params[i++]->name());
  return TheFunction;
}
Value *ProgramASTnode::codegen(){
  for (int i = 0; i < _extern_list.size(); i++){
    _extern_list[i]->codegen();
  }
  for (int j = 0; j < _decl_list.size(); j++){
    _decl_list[j]->codegen();
  }
  return nullptr;
}

//===----------------------------------------------------------------------===//
// AST Printer
//===----------------------------------------------------------------------===//

inline llvm::raw_ostream &operator<<(llvm::raw_ostream &os,
                                     const ASTnode &ast) {
  os << ast.to_string();
  return os;
}
std::string VarASTnode::to_string() const{
  std::string str = "VarASTnode:\n";
  indent++;
  str += indentStr() + "\"" + _ident + "\"";
  indent--;
  return str;
}
std::string FuncASTnode::to_string() const{
  std::string str = "FuncASTnode:\n";
  indent++;
  str += indentStr() + "\"" + _ident + "\"";
  indent++;
  str += "\n" + indentStr() + "(\n";
  indent++;
  for (int i = 0; i < _args.size(); i++){
    str+= indentStr() + _args[i]->to_string() + "\n";
  }
  indent--;
  str+= indentStr() + ")";
  indent--;
  return str;
}
std::string ExprASTnode::to_string() const{
  std::string str = "ExprASTnode:\n";
  indent++;
  if (!_var){
    str += indentStr() + _rval->to_string();
  }
  else{
    str += indentStr() + _var->to_string() + "\n" + indentStr() + "=\n" + indentStr() + _expr->to_string();
  }
  indent--;
  return str;
}
std::string RvalASTnode::to_string() const{
  std::string str = "RvalASTnode:\n";
  indent++;
  if (_neg == MINUS){
    str+= indentStr() + "MINUS\n";
    indent++;
    str+= indentStr() + _rval->to_string();
    indent--;
  }
  else if (_neg == NOT){
    str+= indentStr() + "NOT\n";
    indent++;
    str+= indentStr() + _rval->to_string();
    indent--;
  }
  else{
    if (_in_par){
      str += indentStr() + "(\n";
      indent++;
      str += indentStr() + _in_par->to_string() + "\n";
      indent--;
      str+= indentStr() + ")";
    }
    else if (_lit) str += indentStr() + _lit->to_string();
    else if (_var){
      str += indentStr() + _var->to_string();
    } 
    else if (_func){
      str += indentStr() + _func->to_string();
    }
    str += "\n" + indentStr() + _next->to_string();
  }
  indent--;
  return str;
}
std::string Rval_ASTnode::to_string() const{
  std::string str = "Rval_ASTnode:";
  if (_next){
    indent++;
    str += "\n" + indentStr() + tokStr(_op) + "\n" + indentStr() + _next->to_string();
    indent--;
  }
  return str;
}
std::string LocalDeclASTnode::to_string() const{
  std::string str = "LocalDeclASTnode:\n";
  indent++;
  str += indentStr() + tokStr(_var_type) + "\n" + indentStr() + _var->to_string();
  indent--;
  return str;
}
std::string BlockASTnode::to_string() const{
  std::string str = "BlockASTnode:\n";
  indent++;
  str += indentStr() + "{";
  for (int i = 0; i < _local_decls.size(); i++){
    str += "\n" + indentStr() + _local_decls[i]->to_string();
  }
  for (int i = 0; i < _stmt_list.size(); i++){
    str += "\n" + indentStr() + _stmt_list[i]->to_string();
  }
  str += "\n" + indentStr() + "}";
  indent--;
  return str;
}
std::string ParamASTnode::to_string() const{ 
  std::string str = "ParamASTnode:\n";
  indent++;
  str += indentStr() + tokStr(_var_type) + "\n" + indentStr() + _var->to_string();
  indent--;
  return str;
}
std::string ReturnStmtASTnode::to_string() const{
  std::string str = "ReturnStmtASTnode:\n";
  indent++;
  str += indentStr() + _expr->to_string();
  indent--;
  return str;
}
std::string IfStmtASTnode::to_string() const{ 
  std::string str = "IfStmtASTnode\n";
  indent++;
  str += indentStr() + "If\n";
  indent++;
  str += indentStr() + _cond->to_string() + "\n";
  indent--;
  str += indentStr() + "Then\n";
  indent++;
  str += indentStr() + _then->to_string();
  indent--;
  if (_else){
    str += "\n" + indentStr() + "Else\n";
    indent++;
    str += indentStr() + _else->to_string();
    indent--;
  }
  indent --;
  return str;
}
std::string WhileStmtASTnode::to_string() const{
  std::string str = "WhileStmt:\n";
  indent++;
  str += indentStr() + "While\n";
  indent++;
  str+= indentStr() + _cond->to_string() + "\n";
  indent--;
  str+= indentStr() + "Do\n";
  indent++;
  str += indentStr() +_loop->to_string();
  indent -= 2;
  return str;
}
std::string ExprStmtASTnode::to_string() const{
  std::string str = "ExprStmtASTnode:\n";
  indent++;
  str += indentStr() + _expr->to_string();
  indent--;
  return str;
}
std::string FunDeclASTnode::to_string() const{ 
  std::string str = "FunDeclASTnode:\n";
  indent++;
  str += indentStr() + tokStr(_type_spec) + "\n";
  str += indentStr() + _var->to_string() + "\n" + indentStr() + "(\n";
  if (_is_void){
    str += indentStr() + "void\n";
  }
  else{ 
    for (int i = 0; i < _params.size(); i++){
      str += indentStr() + _params[i]->to_string() + "\n";
    }
  }
  str += indentStr() + ")\n";
  str += indentStr() + _block->to_string();
  return str;
}
std::string VarDeclASTnode::to_string() const{
  std::string str = "VarDeclASTnode:\n";
  indent++;
  str += indentStr() + tokStr(_var_type) + "\n" + indentStr() + _var->to_string();
  indent--;
  return str;
}
std::string ExternASTnode::to_string() const{ 
  std::string str;
  str = "ExternASTnode:\n";
  indent++;
  str += indentStr() + tokStr(_type_spec) + "\n";
  str += indentStr() + _var->to_string() + "\n" + indentStr() + "(\n" + indentStr();
  if (_is_void){
    str += "void";
  } 
  else{
    for (int i = 0; i < _params.size(); i++){
      if (i > 0) str += ",\n" + indentStr();
      str += _params[i]->to_string();
    }  
  }
  str += "\n" + indentStr() + ")";
  indent--;
  return str;
}
std::string ProgramASTnode::to_string() const{ 
  indent = 0;
  std::string str = "ProgramASTnode: ";
  indent++;
  for (int i = 0; i < _extern_list.size(); i++){
    str += "\n" + indentStr() + _extern_list[i]->to_string();
  }
  for (int i = 0; i < _decl_list.size(); i++){
    str+= "\n" + indentStr() + _decl_list[i]->to_string();
  }
  indent--;
  return str;
}

//===----------------------------------------------------------------------===//
// Main driver code.
//===----------------------------------------------------------------------===//

int main(int argc, char **argv) {
  if (argc == 2) {
    pFile = fopen(argv[1], "r");
    if (pFile == NULL)
      perror("Error opening file");
  } else {
    std::cout << "Usage: ./code InputFile\n";
    return 1;
  }

  // initialize line number and column numbers to zero
  lineNo = 1;
  columnNo = 1;

  makeFirst();

  // Make the module, which holds all the code.
  TheModule = std::make_unique<Module>("mini-c", TheContext);

  // Run the parser now.
  parser();
  std::string ln = "#------------------------------#";
  fprintf(stderr, "\n%s\n Parsing Finished. Printing IR:\n%s\n\n", ln.c_str(), ln.c_str());

  //********************* Start printing final IR **************************
  // Print out all of the generated code into a file called output.ll
  auto Filename = "output.ll";
  std::error_code EC;
  raw_fd_ostream dest(Filename, EC, sys::fs::OF_None);

  if (EC) {
    errs() << "Could not open file: " << EC.message();
    return 1;
  }
  TheModule->print(errs(), nullptr); // print IR to terminal
  TheModule->print(dest, nullptr);
  //********************* End printing final IR ****************************

  fclose(pFile); // close the file that contains the code that was parsed
  return 0;
}
