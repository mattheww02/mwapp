﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.IO;

namespace A_Level_Project_1._4
{
    public class Menu //main menu screen which is shown when the game starts
    {
        #region FIELDS
        private const Keys start_key = Keys.Space; //key to start playing the game
        private const string background_texture_file_name = "interface/main_menu";
        private readonly Texture2D background_texture;
        #endregion

        #region PROCEDURES
        public Menu()
        {
            try
            {
                background_texture = Game1.content_loader.Load<Texture2D>(background_texture_file_name);
            }
            catch (FileNotFoundException)
            {
                Game1.game_state = Game1.GameState.game_error;
            }
        }
        public void Update()
        {
            if (Game1.key_state.IsKeyDown(start_key) && Game1.old_key_state.IsKeyUp(start_key)) //character selection will start when start key is pressed
            { Game1.game_state = Game1.GameState.character_select; }
        }
        public void Draw(SpriteBatch sprite_batch)
        {
            sprite_batch.Draw(background_texture, new Rectangle(0, 0, Game1.resolution.X, Game1.resolution.Y), Color.White);
        }
        #endregion
    }
}
