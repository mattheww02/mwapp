﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class PlayerBase
    {
        #region FIELDS
        private readonly string name; //name displayed on player selection screen and high score screen
        private readonly Texture2D alive_texture;
        private readonly Texture2D hurt_texture;
        private readonly Texture2D dead_texture;
        private readonly Texture2D walk_texture;
        private readonly Point size;
        private readonly int max_health;
        private readonly int health_regen_per_level; //amount of health regained at the end of each level (can't increase past max health)
        private readonly float max_speed; //fastest movement speed
        private readonly float acceleration;
        private readonly float deceleration;
        private readonly Weapon.WeaponType start_weapon_type; //starting weapon type for first level
        private readonly float start_enemy_multiplier; //affects number of enemies generated at the start of a level

        public string Name => name;
        public Texture2D Alive_texture => alive_texture;
        public Texture2D Hurt_texture => hurt_texture;
        public Texture2D Dead_texture => dead_texture;
        public Texture2D Walk_texture => walk_texture;
        public Point Size => size;
        public int Max_health => max_health;
        public int Health_regen_per_level => health_regen_per_level;
        public float Max_speed => max_speed;
        public float Acceleration => acceleration;
        public float Deceleration => deceleration;
        public Weapon.WeaponType Start_weapon_type => start_weapon_type;
        public float Start_enemy_multiplier => start_enemy_multiplier;
        #endregion

        #region CONSTRUCTOR
        public PlayerBase(List <string> file_line) //settings loaded from text file line by line
        {
            name = file_line[1];
            alive_texture = Game1.content_loader.Load<Texture2D>(file_line[2]);
            hurt_texture = Game1.content_loader.Load<Texture2D>(file_line[3]);
            dead_texture = Game1.content_loader.Load<Texture2D>(file_line[4]);
            size = new Point(Convert.ToInt32(file_line[5]), Convert.ToInt32(file_line[6]));
            max_health = Convert.ToInt32(file_line[7]);
            health_regen_per_level = Convert.ToInt32(file_line[8]);
            max_speed = Convert.ToSingle(file_line[9]);
            acceleration = Convert.ToSingle(file_line[10]);
            deceleration = Convert.ToSingle(file_line[11]);
            start_weapon_type = (Weapon.WeaponType)Convert.ToInt32(file_line[12]);
            start_enemy_multiplier = Convert.ToSingle(file_line[13]);
            walk_texture = Game1.content_loader.Load<Texture2D>(file_line[14]);
        }
        #endregion
    }
}
