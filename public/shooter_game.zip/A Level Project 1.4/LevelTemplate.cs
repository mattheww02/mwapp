﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.IO;

namespace A_Level_Project_1._4
{
    public class LevelTemplate //contains information about rooms, textures and enemies in a type of level
    {
        #region FIELDS
        public readonly string[] room_file_names; //file name of rooms that can be generated in a level
        public readonly string[] level_texture_file_names; //file name of tile textures in the level
        public readonly float[] enemy_amounts; //proportion of each enemy type that appears in the level
        #endregion

        #region CONSTRUCTOR
        public LevelTemplate(string rooms, string textures, string enemies)
        {
            const char split_char = '-';
            room_file_names = rooms.Split(split_char);
            level_texture_file_names = textures.Split(split_char);
            string[] enemy_strings = enemies.Split(split_char);
            enemy_amounts = new float[enemy_strings.Length];
            for (int i = 0; i < enemy_strings.Length; i++)
            {
                enemy_amounts[i] = Convert.ToSingle(enemy_strings[i]);
            }
        }
        #endregion
    }
}
