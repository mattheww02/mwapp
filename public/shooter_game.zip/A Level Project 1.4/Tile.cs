﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class Tile //a tile displayed as a single element of a level
    {
        #region FIELDS
        private readonly Texture2D texture; //texture used to display the entity
        private readonly bool solid; //entities collide with solid tiles

        public Texture2D Texture { get => texture; }
        public bool Solid { get => solid; }
        #endregion

        #region CONSTRUCTOR
        public Tile(string file_name, bool _solid)
        {
            texture = Game1.content_loader.Load<Texture2D>(file_name);
            solid = _solid;
        }
        #endregion
    }
}
