﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class GameError //displays an error message when an exception is caught
    {
        #region FIELDS
        private const string display_font_file_name = "score_font";
        private const string error_string = "ERROR: FILE NOT FOUND";
        private const string instruction_string = "PRESS ESCAPE TO EXIT";
        private readonly Vector2 error_string_location = new Vector2(620, 550);
        private readonly Vector2 instruction_string_location = new Vector2(630, 600);
        private readonly SpriteFont display_font;
        #endregion

        #region PROCEDURES
        public GameError()
        {
            display_font = Game1.content_loader.Load<SpriteFont>(display_font_file_name);
        }
        public void Draw(SpriteBatch sprite_batch)
        {
            sprite_batch.DrawString(display_font, error_string, error_string_location, Color.White);
            sprite_batch.DrawString(display_font, instruction_string, instruction_string_location, Color.White);
        }
        #endregion
    }
}
