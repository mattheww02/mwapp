﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;
using System.IO;
   
namespace A_Level_Project_1._4
{
    public class Game1 : Game //updates and draws game, contains information on current state of game
    {
        #region FIELDS
        public enum GameState //the current state of the game (can only be in 1 state at a time)
        {
            menu,
            character_select,
            playing,
            game_over,
            level_complete,
            high_scores,
            game_error
        }
        public static KeyboardState key_state; //keys pressed at any point in time
        public static KeyboardState old_key_state; //keys pressed during the previous update
        public static MouseState mouse_state; //mouse location and mouse buttons pressed
        public static MouseState old_mouse_state; //mouse location and mouse buttons pressed last update
        public static ContentManager content_loader; //loads content for other classes
        public static Point resolution = new Point(1920, 1080); //resolution of the game window
        public static Random random; //allows classes to generate random numbers which are different each time
        public static GameState game_state; //determines which classes are updated
        private const Keys escape_key = Keys.Escape; //key used to close the game
        private const string weapons_file_name = "/weapons.txt";
        private const string enemies_file_name = "/enemies.txt";
        private const string players_file_name = "/players.txt";
        private const string levels_file_name = "/level_templates.txt";
        private int level_number; //current level the player is on
        private bool loading_next_state;
        private GameState old_game_state;
        private Menu current_menu; //one instance of each game state can be used at a time
        private CharacterSelect current_character_select;
        private Level current_level;
        private GameOver current_game_over;
        private LevelComplete current_level_complete;
        private HighScores current_high_scores;
        private GameError current_game_error;
        private Player player_char; //player's character
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private Dictionary<Enemy.EnemyType, EnemyBase> enemy_templates; //templates for enemies can be copied into a level
        private Dictionary<Weapon.WeaponType, WeaponBase> weapon_templates; //stores each type of weapon
        private Dictionary<Player.PlayerType, PlayerBase> player_templates; //stores player type templates
        private List<LevelTemplate> level_templates; //templates for different types of levels
        #endregion

        #region INITIALISATION
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            content_loader = Content;
        }
        protected override void Initialize() //runs processes that only need to be run once at the start of the game
        { 
            Mouse.SetCursor(MouseCursor.Crosshair); //crosshair replaces mouse cursor
            IsMouseVisible = true;
            graphics.PreferredBackBufferWidth = resolution.X;
            graphics.PreferredBackBufferHeight = resolution.Y;
            graphics.ApplyChanges();
            random = new Random();  
            game_state = GameState.menu;
            current_menu = new Menu();
            LoadWeapons(Content.RootDirectory + weapons_file_name);
            LoadEnemies(Content.RootDirectory +  enemies_file_name);
            LoadPlayers(Content.RootDirectory +  players_file_name);
            LoadLevels(Content.RootDirectory + levels_file_name);
            base.Initialize();
        }
        #endregion

        #region CONTENT LOADING
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
        }
        private void LoadWeapons(string dir) //loads information about each type of weapon available in the game
        {
            const string reader_end_string = "END";
            const char reader_split_char = '/';
            StreamReader reader;
            try
            {
                reader = new StreamReader(dir);
                List<string> current_line = new List<string>(); //each element in the list is a characteristic of a weapon
                weapon_templates = new Dictionary<Weapon.WeaponType, WeaponBase>(); //stores templates for each type of weapon in the game
                current_line = reader.ReadLine().ToString().Split(reader_split_char).ToList(); //splits each line into a list of string elements
                Weapon.WeaponType w = (Weapon.WeaponType)Convert.ToInt32(current_line[0]);
                while (current_line[0] != reader_end_string) //the settings file has to have this exact format to work properly
                { //sets characteristics of a weapon and adds it to the dictionary of weapon templates
                    weapon_templates.Add(w, new WeaponBase(current_line));
                    current_line = new List<string>();
                    current_line = reader.ReadLine().ToString().Split(reader_split_char).ToList();
                    if (current_line[0] != reader_end_string)
                    {
                        w = (Weapon.WeaponType)Convert.ToInt32(current_line[0]);
                    }       
                }
                reader.Close();
            }
            catch (FileNotFoundException)
            {
                game_state = GameState.game_error;
            }
        }
        private void LoadEnemies(string dir) //loads enemy template information to be stored in a dictionary
        { //works in the same way as the LoadWeapons sub above
            const string reader_end_string = "END";
            const char reader_split_char = '/';
            StreamReader reader;
            try
            {
                reader = new StreamReader(dir);     
                List<string> current_line = new List<string>();           
                enemy_templates = new Dictionary<Enemy.EnemyType, EnemyBase>();
                current_line = reader.ReadLine().ToString().Split(reader_split_char).ToList();
                Enemy.EnemyType e = (Enemy.EnemyType)Convert.ToInt32(current_line[0]);
                while (current_line[0] != reader_end_string)
                { //sets characteristics of an enemy
                    enemy_templates.Add(e, new EnemyBase(current_line));

                    current_line = new List<string>();
                    current_line = reader.ReadLine().ToString().Split(reader_split_char).ToList();
                    if (current_line[0] != reader_end_string)
                    {
                        e = (Enemy.EnemyType)Convert.ToInt32(current_line[0]);
                    }    
                }
                reader.Close();
            }
            catch (FileNotFoundException)
            {
                game_state = GameState.game_error;
            }
        }
        private void LoadPlayers(string dir) //loads player type information from text file
        { //same function as LoadWeapons and LoadEnemies, different data loaded from file
            const string reader_end_string = "END";
            const char reader_split_char = '/';
            StreamReader reader;
            try
            {
                reader = new StreamReader(dir);
                List<string> current_line = new List<string>();
                player_templates = new Dictionary<Player.PlayerType, PlayerBase>();
                current_line = reader.ReadLine().ToString().Split(reader_split_char).ToList();
                Player.PlayerType p = (Player.PlayerType)Convert.ToInt32(current_line[0]);
                while (current_line[0] != reader_end_string)
                { //sets characteristics of a player
                    player_templates.Add(p, new PlayerBase(current_line));

                    current_line = new List<string>();
                    current_line = reader.ReadLine().ToString().Split(reader_split_char).ToList();
                    if (current_line[0] != reader_end_string)
                    {
                        p = (Player.PlayerType)Convert.ToInt32(current_line[0]);
                    }
                }
                reader.Close();
            }
            catch (FileNotFoundException)
            {
                game_state = GameState.game_error;
            }
        }
        private void LoadLevels(string dir) //loads templates for different types of levels
        {
            level_templates = new List<LevelTemplate>();
            try
            {
                StreamReader reader = new StreamReader(dir);
                while (!reader.EndOfStream)
                { //each level template is represented by 3 lines of text in a file
                    level_templates.Add(new LevelTemplate(reader.ReadLine(), reader.ReadLine(), reader.ReadLine()));
                }
                reader.Close();
            }
            catch (FileNotFoundException)
            {
                game_state = GameState.game_error;
            }
        }
        #endregion

        #region UPDATE AND DRAW GAME
        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(escape_key)) //game can be closed at any time by pressing escape key
                Exit();

            loading_next_state = (game_state != old_game_state); //checks if game state has been changed

            if (loading_next_state && old_game_state == GameState.character_select) //makes a new character with type based on player's selection and resets game
            {
                level_number = 1;
                Player.PlayerType new_player_type = current_character_select.GetNewPlayerType();
                player_char = new Player(player_templates[new_player_type], ref weapon_templates);
                ShuffleLevelTemplates(); //randomises order of levels
            }

            old_game_state = game_state; //stores current and previous state of game and inputs
            old_key_state = key_state;
            old_mouse_state = mouse_state;
            key_state = Keyboard.GetState();
            mouse_state = Mouse.GetState();

            switch (game_state) //updates and instantiates a class based on the current game state
            {
                case GameState.menu:
                    if (loading_next_state)
                    {
                        current_menu = new Menu();
                    }
                    current_menu.Update();
                    break;
                case GameState.character_select:
                    if (loading_next_state)
                    {
                        current_character_select = new CharacterSelect(ref player_templates);
                    }
                    current_character_select.Update();
                    break;
                case GameState.playing:
                    if (loading_next_state)
                    {
                        current_level = new Level(level_number, ref player_char, ref enemy_templates, ref weapon_templates, level_templates[level_number % level_templates.Count()]);
                    } //the level template used changes each time a new level is started
                    else
                    {
                        current_level.Update(gameTime);
                    }
                    break;
                case GameState.game_over:
                    if (loading_next_state)
                    {
                        current_game_over = new GameOver();
                    }
                    current_game_over.Update();
                    break;
                case GameState.level_complete:
                    if (loading_next_state)
                    {
                        current_level_complete = new LevelComplete(ref player_char, current_level.Time_elapsed, ref level_number);
                    }
                    current_level_complete.Update();
                    break;
                case GameState.high_scores:
                    if (loading_next_state)
                    {
                        current_high_scores = new HighScores(player_char.Score, player_char.Name);
                    }
                    current_high_scores.Update();
                    break;
                case GameState.game_error:
                    if (loading_next_state)
                    {
                        current_game_error = new GameError();
                        old_game_state = GameState.game_error; //other states don't need to be updated / drawn if an error occurs
                    }
                    break;
            }
            base.Update(gameTime);
        }
        protected override void Draw(GameTime gameTime)
        {
            if (!loading_next_state)
            {
                GraphicsDevice.Clear(Color.Black);
                spriteBatch.Begin();
                switch (old_game_state) //draws the class that is currently being used (doesn't draw new game state until it has loaded)
                {
                    case GameState.menu:
                        current_menu.Draw(spriteBatch);
                        break;
                    case GameState.character_select:
                        current_character_select.Draw(spriteBatch);
                        break;
                    case GameState.playing:
                        current_level.Draw(spriteBatch);
                        break;
                    case GameState.game_over:
                        current_level.Draw(spriteBatch); //draws level behind game over screen
                        current_game_over.Draw(spriteBatch);
                        break;
                    case GameState.level_complete:
                        current_level.Draw(spriteBatch); //draws level behind level complete screen
                        current_level_complete.Draw(spriteBatch);
                        break;
                    case GameState.high_scores:
                        current_high_scores.Draw(spriteBatch);
                        break;
                    case GameState.game_error:
                        current_game_error.Draw(spriteBatch);
                        break;
                }
                spriteBatch.End();
            }
            base.Draw(gameTime);
        }
        private void ShuffleLevelTemplates() //randomises the order of level templates in the list
        {
            int r;
            LevelTemplate temp;
            for (int i = 0; i < level_templates.Count(); i++)
            {
                r = random.Next(0, level_templates.Count()); //gets a random template from the list
                temp = level_templates[i]; //swaps position in list of the two templates
                level_templates[i] = level_templates[r];
                level_templates[r] = temp;
            }
        }
        #endregion
    }
}
