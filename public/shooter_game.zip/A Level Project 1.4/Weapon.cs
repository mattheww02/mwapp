﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class Weapon //affects how projectiles are shot by the player or an enemy
    {
        #region FIELDS
        public enum WeaponType
        {
            none,
            pistol,
            smg,
            sniper,
            shotgun,
            rifle,
            rocket_launcher,
            flame_thrower,
            plant_gun,
            minigun
        }

        private readonly WeaponBase weapon_base; //contains constant information about weapon type
        private Point gun_location; //location of weapon texture
        private int last_shot; //records time a projectile was shot from this
        private int current_ammo; //number of projectiles left to shoot before reloading
        private int last_reload; //time at last reload
        
        public Point Gun_location { get => gun_location; set => gun_location = value; }
        public int Last_shot { get => last_shot; }
        public int Current_ammo { get => current_ammo; }
        public int Last_reload { get => last_reload; }
        public WeaponBase Weapon_base { get => weapon_base; }
        #endregion

        #region CONSTRUCTOR
        public Weapon(WeaponType weapon_type, ref Dictionary<WeaponType, WeaponBase> weapon_templates)
        {
            weapon_base = weapon_templates[weapon_type];
            last_shot = 0;
            current_ammo = weapon_base.Max_ammo;
        }
        #endregion

        #region WEAPON UPDATING
        public void Shoot(int time) //tells the weapon a projectile has been shot- doesn't actually create the projectile
        {
            if (weapon_base.Max_ammo > 0) //subtracts ammo if weapon uses ammo
            {
                current_ammo--;
            }
            last_shot = time;
        }
        public void RefillAmmo() //sets ammo to full
        {
            current_ammo = weapon_base.Max_ammo;
        }
        public void StartReload(int time) //sets time of last reload
        {
            last_reload = time;
        }
        public bool FinishedShooting(int time) //checks if the weapon has finished shooting
        {
            return (last_shot + weapon_base.Shot_delay <= time);
        }
        public bool FinishedReload(int time) //checks if the weapon has finished reloading
        {
            return (last_reload + weapon_base.Reload_time <= time);
        }
        public float GetReloadPercent(int time) //returns how far the weapon is through the reload process
        {
            return (float)(time - last_reload) / weapon_base.Reload_time;
        }
        #endregion
    }
}
