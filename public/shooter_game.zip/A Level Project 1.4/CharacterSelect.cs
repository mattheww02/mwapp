﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class CharacterSelect //menu that allows player to select a character type from a list of options
    {
        #region FIELDS
        private const string arrow_up_texture_file_name = "interface/arrow_up";
        private const string arrow_down_texture_file_name = "interface/arrow_down";
        private const string background_texture_file_name = "interface/character_selection";
        private const string player_font_file_name = "score_font";
        private const Keys prev_key = Keys.W; //keys used to control selection
        private const Keys next_key = Keys.S;
        private const Keys select_key = Keys.Space;
        private const float animation_speed = 0.17f; //rate at which sprite animations play
        private const int player_width = 64;
        private const int player_height = 64;
        private const int arrow_y_offset = 12;
        private const int time_to_show_selection = 30; //amount of time after selection to show character
        private const int player_blink_interval_start = 5;
        private const int player_blink_interval_end = 10;

        private readonly Rectangle character_texture_dimensions = new Rectangle(700, 500, 128, 128); //size and location of textures displayed in menu
        private readonly Rectangle up_arrow_dimensions = new Rectangle(722, 370, 84, 48);
        private readonly Rectangle down_arrow_dimensions = new Rectangle(722, 700, 84, 48);
        private readonly Vector2 character_string_location = new Vector2(956, 548);
        private readonly Vector2 string_shadow_offset = new Vector2(6, 6);

        private Dictionary<Player.PlayerType, PlayerBase> player_templates;
        private Texture2D background_texture;
        private Texture2D up_arrow_texture;
        private Texture2D down_arrow_texture;
        private SpriteFont player_font;
        private int current_selection; //index of current character selection in list of character types
        private int selection_shown_time; //amount of time since character has been selected
        private bool player_selected; //whether character has been selected
        private int arrow_selected = 0; //indicates which arrow has been selected in the last update
        private long time_elapsed = 0;
        #endregion

        #region PROCEDURES
        public CharacterSelect(ref Dictionary<Player.PlayerType, PlayerBase> _player_templates)
        {
            player_templates = _player_templates;
            current_selection = 0;
            player_selected = false;
            selection_shown_time = 0;
            up_arrow_texture = Game1.content_loader.Load<Texture2D>(arrow_up_texture_file_name);
            down_arrow_texture = Game1.content_loader.Load<Texture2D>(arrow_down_texture_file_name);
            background_texture = Game1.content_loader.Load<Texture2D>(background_texture_file_name);
            player_font = Game1.content_loader.Load<SpriteFont>(player_font_file_name);
        }
        public void Update()
        {
            time_elapsed++;
            arrow_selected = 0;
            if (player_selected) //checks if current selection has been confirmed
            {
                if (selection_shown_time >= time_to_show_selection)
                { Game1.game_state = Game1.GameState.playing; }
                selection_shown_time++; //there is a short delay between selecting a character and starting the game to allow for a short animation
            }
            else
            {
                if (Game1.key_state.IsKeyDown(prev_key) && !Game1.old_key_state.IsKeyDown(prev_key)) //checks if 'previous' button is pressed (but not held)
                { //moves selection to previous index
                    if (current_selection - 1 < 0)
                    { current_selection = player_templates.Count() - 1; }
                    else
                    { current_selection--; }
                    arrow_selected = -1;
                }
                else if (Game1.key_state.IsKeyDown(next_key) && !Game1.old_key_state.IsKeyDown(next_key)) //checks if 'next' buttone is pressed
                { //moves selection to next index
                    if (current_selection + 1 > player_templates.Count() - 1)
                    { current_selection = 0; }
                    else
                    { current_selection++; }
                    arrow_selected = 1;
                }
                else if (Game1.key_state.IsKeyDown(select_key) && !Game1.old_key_state.IsKeyDown(select_key)) //checks if 'select' button is pressed
                { player_selected = true; } //selects character and allows game to start
            }
            
        }
        public void Draw(SpriteBatch sprite_batch)
        {
            int up_arrow_offset = 0; //up and down arrows are offset for a short time when pressed
            int down_arrow_offset = 0;
            Texture2D player_texture;
            if (player_selected && selection_shown_time % player_blink_interval_end < player_blink_interval_start) //player flashes when selected
            { player_texture = player_templates[(Player.PlayerType)current_selection].Hurt_texture; }
            else
            { player_texture = player_templates[(Player.PlayerType)current_selection].Alive_texture; }
            if (arrow_selected == 1) //offsets selected arrow if pressed
            { down_arrow_offset = arrow_y_offset; }
            else if (arrow_selected == -1)
            { up_arrow_offset = arrow_y_offset; }

            sprite_batch.Draw(background_texture, new Rectangle(new Point(0, 0), Game1.resolution), Color.White);
            sprite_batch.Draw(player_texture, character_texture_dimensions, new Rectangle((int)(time_elapsed * player_width * animation_speed) % player_texture.Width / player_width * player_width, 0, player_width, player_height), Color.White);
            sprite_batch.Draw(up_arrow_texture, new Rectangle(up_arrow_dimensions.X, up_arrow_dimensions.Y - up_arrow_offset, up_arrow_dimensions.Width, up_arrow_dimensions.Height), Color.White);
            sprite_batch.Draw(down_arrow_texture, new Rectangle(down_arrow_dimensions.X, down_arrow_dimensions.Y + down_arrow_offset, down_arrow_dimensions.Width, down_arrow_dimensions.Height), Color.White);
            sprite_batch.DrawString(player_font, player_templates[(Player.PlayerType)current_selection].Name.ToUpper(), character_string_location + string_shadow_offset, Color.Black);
            sprite_batch.DrawString(player_font, player_templates[(Player.PlayerType)current_selection].Name.ToUpper(), character_string_location, Color.White);
        }
        public Player.PlayerType GetNewPlayerType() //returns character type currently selected (not necessarily player's final selection if selection isn't confirmed)
        {
            return (Player.PlayerType)current_selection;
        }
        #endregion
    }
}
