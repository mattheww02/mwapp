﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.IO;

namespace A_Level_Project_1._4
{
    public class HighScores //a screen for the player to enter their name and view high scores
    {
        #region FIELDS
        private const Keys next_key = Keys.Space; //key pressed to submit score or to exit to menu
        private const Keys back_key = Keys.Back; //key pressed to delete last character entered
        private const string allowed_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //valid name characters
        private const string high_scores_file_name = "/high_scores.txt"; //name of the file that stores high scores and names
        private const string enter_score_texture_file_name = "interface/enter_high_score";
        private const string show_score_texture_file_name = "interface/high_scores_screen";
        private const string score_font_file_name = "score_font";
        private const string score_format_long = "D6";
        private const int text_blink_interval_start = 30; //interval at which blinking text will appear / disappear
        private const int text_blink_interval_end = 60;
        private const int max_high_scores = 10; //number of scores that can be in the list of high scores at a time
        private const char blank_char = '_'; //name characters appear as this character when empty
        private readonly Point list_text_start_location = new Point(650, 200); //location on screen of first string in list of high scores to be displayed
        private readonly Point list_text_offset = new Point(180, 55); //displacement of next string from previous when displaying high scores
        private readonly Point new_text_start_location = new Point(850, 550); //location of first character shown when name is entered for new score
        private readonly Point new_text_offset = new Point(80, 0); //distance between characters in new name
        private readonly Texture2D enter_score_texture;
        private readonly Texture2D show_scores_texture;
        private readonly SpriteFont score_font;
        private int new_score; //score from most recent game
        private int current_char; //index in name of currently selected character
        private int game_ticks; //amount of time class has existed
        private int player_position; //position in high score list of new score
        private string new_player_type; //player type from most recent game
        private char[] name; //name to be displayed on score screen
        private bool score_submitted; //checks whether name has been entered (to allow score to be submitted)
        private List<int> high_scores; //high scores loaded from file
        private List<string> high_score_names; //name given for each high score
        private List<string> high_score_types; //character type used for each high score
        #endregion

        #region FILE LOADING AND SAVING
        public HighScores(int _new_score, string _new_player_type)
        {
            enter_score_texture = Game1.content_loader.Load<Texture2D>(enter_score_texture_file_name);
            show_scores_texture = Game1.content_loader.Load<Texture2D>(show_score_texture_file_name);
            score_font = Game1.content_loader.Load<SpriteFont>(score_font_file_name);
            new_score = _new_score;
            new_player_type = _new_player_type;
            name = new char[] { blank_char, blank_char, blank_char }; //names are all 3 characters long
            current_char = 0;
            game_ticks = 0;
            score_submitted = false;
            LoadScores();
        }
        private void LoadScores() //loads high scores to display from file
        {
            high_scores = new List<int>();
            high_score_names = new List<string>();
            high_score_types = new List<string>();
            string file_dir = Game1.content_loader.RootDirectory + high_scores_file_name;
            try
            {
            StreamReader reader = new StreamReader(file_dir);
            string[] current_line = new string[1];
            while (high_scores.Count < max_high_scores)
            {
                if (!reader.EndOfStream)
                {
                    current_line = reader.ReadLine().Split('/'); //splits each line into a score and a name
                    high_score_names.Add(current_line[0]);
                    high_scores.Add(Convert.ToInt32(current_line[1]));
                    high_score_types.Add(current_line[2]);
                }
                else
                {
                    high_score_names.Add("___"); //adds blank namees & scores if there aren't enough scores in the file
                    high_scores.Add(0);
                    high_score_types.Add("");
                }   
            }
            reader.Close();
            }catch(FileNotFoundException)
            {
                Game1.game_state = Game1.GameState.game_error;
            }
        }
        public void Update()
        {
            game_ticks++;
            if (score_submitted) //displays high scores after name has been entered
            {
                if (Game1.key_state.IsKeyDown(next_key) && !Game1.old_key_state.IsKeyDown(next_key))
                { Game1.game_state = Game1.GameState.menu; }
            }
            else
            {
                foreach (char c in allowed_chars) //checks if a character has been entered
                {
                    if (Game1.key_state.IsKeyDown((Keys)c) && !Game1.old_key_state.IsKeyDown((Keys)c) && current_char < name.Count())
                    {
                        name[current_char] = c;
                        current_char = Math.Min(name.Count(), current_char + 1);
                    }
                }
                if (Game1.key_state.IsKeyDown(back_key) && !Game1.old_key_state.IsKeyDown(back_key)) //removes the last character
                {
                    current_char = Math.Max(0, current_char - 1);
                    name[current_char] = blank_char;
                }
                if (Game1.key_state.IsKeyDown(next_key) && !name.Contains(blank_char)) //submits the name if it is valid
                {
                    score_submitted = true;
                    AddToList();
                }
            }
        }
        private void AddToList() //adds the player's score and name to the list of high scores
        {
            bool position_found = false;
            string new_name = name[0].ToString() + name[1].ToString() + name[2].ToString();
            player_position = max_high_scores;
            while (!position_found)
            {
                if (player_position == 0) //checks if the player is at the top of the list
                {
                    position_found = true;
                }
                else if (new_score > high_scores[player_position - 1])
                {
                    player_position--; //moves the player up the high score list
                }
                else
                {
                    position_found = true;
                }
            }
            high_scores.Insert(player_position, new_score); //puts new score in the correct position on high scores list
            high_score_names.Insert(player_position, new_name);
            high_score_types.Insert(player_position, new_player_type);
            high_scores.RemoveAt(max_high_scores); //removes the last score on the list to keep the list the correct length
            high_score_names.RemoveAt(max_high_scores);
            SaveScores();
        }
        private void SaveScores() //saves scores and names to a file
        {
            string file_dir = Game1.content_loader.RootDirectory + high_scores_file_name;
            try
            {
                StreamWriter writer = new StreamWriter(file_dir);
                for (int i = 0; i < high_scores.Count; i++)
                {
                    writer.WriteLine(high_score_names[i] + "/" + high_scores[i].ToString() + "/" + high_score_types[i]); //write format must match read format
                }
                writer.Close();
            }
            catch (FileNotFoundException)
            {
                Game1.game_state = Game1.GameState.game_error;
            }
        }
        #endregion

        #region DRAWING
        public void Draw(SpriteBatch sprite_batch)
        { //type drawn depends on if the player's score has been submitted yet
            if (score_submitted)
            { DrawShowScores(sprite_batch); }
            else
            { DrawAddScore(sprite_batch); }
        }
        private void DrawAddScore(SpriteBatch sprite_batch) //draw sub for submitting high score & name
        {
            sprite_batch.Draw(enter_score_texture, new Rectangle(new Point(0, 0), Game1.resolution), Color.White);
            for (int i = 0; i < name.Count(); i++) //displays each character of the name
            { DrawStringShadow(score_font, name[i].ToString(), new_text_start_location.X + new_text_offset.X * i, new_text_start_location.Y, sprite_batch); }
        }
        private void DrawShowScores(SpriteBatch sprite_batch) //draw sub for displaying high scores
        {
            string new_name = name[0].ToString() + name[1].ToString() + name[2].ToString();
            sprite_batch.Draw(show_scores_texture, new Rectangle(new Point(0, 0), Game1.resolution), Color.White);
            for (int i = 0; i < high_scores.Count; i++)
            {
                if (i != player_position || game_ticks % text_blink_interval_end < text_blink_interval_start) //the player's name and score will blink on the high score list
                { //displays name, score and character type of each high score in the list
                    DrawStringShadow(score_font, high_score_names[i], list_text_start_location.X, list_text_start_location.Y + list_text_offset.Y * i, sprite_batch);
                    DrawStringShadow(score_font, high_scores[i].ToString(score_format_long), list_text_start_location.X + list_text_offset.X, list_text_start_location.Y + list_text_offset.Y * i, sprite_batch);
                    DrawStringShadow(score_font, high_score_types[i], list_text_start_location.X + list_text_offset.X * 3, list_text_start_location.Y + list_text_offset.Y * i, sprite_batch);
                }
            }
            DrawStringShadow(score_font, new_name, list_text_start_location.X, list_text_start_location.Y + list_text_offset.Y * (high_score_names.Count() + 1), sprite_batch); //displays current player name
            DrawStringShadow(score_font, new_score.ToString(score_format_long), list_text_start_location.X + list_text_offset.X, list_text_start_location.Y + list_text_offset.Y * (high_score_names.Count() + 1), sprite_batch);
            DrawStringShadow(score_font, new_player_type, list_text_start_location.X + list_text_offset.X * 3, list_text_start_location.Y + list_text_offset.Y * (high_score_names.Count() + 1), sprite_batch);
        }
        private void DrawStringShadow(SpriteFont font, string text, int x, int y, SpriteBatch sprite_batch) //draws a string with an offset 'shadow' copy behind it to create a shadow effect
        {
            const int x_shadow_offset = 6;
            const int y_shadow_offset = 6;
            sprite_batch.DrawString(font, text, new Vector2(x + x_shadow_offset, y + y_shadow_offset), Color.Black);
            sprite_batch.DrawString(font, text, new Vector2(x, y), Color.White);
        }
        #endregion
    }
}
