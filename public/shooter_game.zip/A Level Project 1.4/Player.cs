﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class Player : Entity //contains information about the player's character
    {
        #region FIELDS
        public enum PlayerType //types of playable characters
        {
            fish,
            crystal,
            crow,
            croc,
            chicken
        }

        private const Keys key_up = Keys.W; //controls for movement
        private const Keys key_down = Keys.S;
        private const Keys key_left = Keys.A;
        private const Keys key_right = Keys.D;
        private const Keys key_reload = Keys.R;
        private const int immune_flash_start = 5; //intervals at which player will flash when in immune state
        private const int immune_flash_end = 10;
        private int immune_ticks_remaining = 0; //number of ticks until player can lose health again after taking damage
        private readonly PlayerBase player_base; //constant 
        
        private Weapon current_weapon; //the weapon the player is holding
        private bool shooting; //checks if the player is shooting
        private bool reloading; //checks if player is reloading
        private bool facing_right; //checks if mouse is to left or right of player character
        private int score; //score is gained by completing levels and killing enemies, and can be submitted at the end of a game
        private int health; //if player's health reaches 0, it dies
        private float reload_percent; //reload progress (indicates time until weapon reload is complete)

        public Weapon Current_weapon { get => current_weapon; }
        public bool Shooting { get => shooting; }
        public bool Reloading { get => reloading; }
        public bool Facing_right { get => facing_right; }
        public int Score { get => score; }
        public int Health { get => health; }
        public int Max_health { get => player_base.Max_health; }
        public float Start_enemy_multiplier { get => player_base.Start_enemy_multiplier; }
        public float Reload_percent { get => reload_percent; }
        public string Name { get => player_base.Name; }
        #endregion

        #region PROCEDURES
        public Player(PlayerBase _player_base, ref Dictionary<Weapon.WeaponType, WeaponBase> weapon_templates)
        {
            const int player_death_duration = 50;
            player_base = _player_base; //player base contains constant information about selected player type
            health = player_base.Max_health;
            current_texture = player_base.Alive_texture;
            hitbox = new Rectangle(0, 0, player_base.Size.X, player_base.Size.Y);
            current_weapon = new Weapon(player_base.Start_weapon_type, ref weapon_templates);//player_base.Start_weapon_type);
            death_texture = player_base.Dead_texture;
            death_size = player_base.Size;
            death_duration = player_death_duration;
            score = 0;
            reload_percent = 0;
        }
        public void Update(GameTime game_time)
        {
            if (Alive) //executes if the player is still alive
            {
                UpdateMove();
                UpdateShooting(game_time);
                UpdateTexture();
            }
            base.Update();
        }
        private void UpdateMove() //updates velocity based on input
        {
            bool x_accelerating = false; //checks if player is accelerating in x/y direction (otherwise the player will decelerate)
            bool y_accelerating = false;
            if (Game1.key_state.IsKeyDown(key_up)) //allows player to accelerate up/down/left/right
            {
                ChangeVelocity(0, -player_base.Acceleration, player_base.Max_speed);
                y_accelerating = true;
            }
            if (Game1.key_state.IsKeyDown(key_down))
            {
                ChangeVelocity(0, player_base.Acceleration, player_base.Max_speed);
                y_accelerating = true;
            }
            if (Game1.key_state.IsKeyDown(key_left))
            {
                ChangeVelocity(-player_base.Acceleration, 0, player_base.Max_speed);
                x_accelerating = true;
            }
            if (Game1.key_state.IsKeyDown(key_right))
            {
                ChangeVelocity(player_base.Acceleration, 0, player_base.Max_speed);
                x_accelerating = true;
            }
            if (!x_accelerating) //decelerates in x direction if not accelerating
            {
                ChangeVelocity(-player_base.Deceleration * Math.Sign(velocity.X), 0, 0);
            }
            if (!y_accelerating) //decelerates in y direction if not accelerating
            {
                ChangeVelocity(0, -player_base.Deceleration * Math.Sign(velocity.Y), 0);
            }
        }
        private void UpdateShooting(GameTime game_time) //updates shooting and reloading
        {
            int time_ms = (int)game_time.TotalGameTime.TotalMilliseconds; //game time in milliseconds
            shooting = false;
            if (Game1.mouse_state.LeftButton == ButtonState.Pressed) //checks if the player is shooting state
            {
                if (current_weapon.Weapon_base.Automatic || Game1.old_mouse_state.LeftButton == ButtonState.Released) //if the player's weapon is automatic, the shoot button can be held down
                {
                    shooting = true;
                }
            }
            if ((current_weapon.Current_ammo == 0 || (Game1.key_state.IsKeyDown(key_reload) && current_weapon.Current_ammo < current_weapon.Weapon_base.Max_ammo)) && !reloading)
            {
                reloading = true;
                current_weapon.StartReload((int)game_time.TotalGameTime.TotalMilliseconds);
            }
            if (reloading)
            {
                reload_percent = current_weapon.GetReloadPercent(time_ms);
            }
        }
        private void UpdateTexture() //updates player character texture based on state
        {
            if (velocity.Length() > 0) //checks if player is moving
            { current_texture = player_base.Walk_texture; }
            else
            { current_texture = player_base.Alive_texture; }
            if (immune_ticks_remaining > 0) //checks if the player is immune from damage
            {
                immune_ticks_remaining--;
                if (immune_ticks_remaining % immune_flash_end >= immune_flash_start) //the player flashes if it is immune
                {
                    current_texture = player_base.Hurt_texture;
                }
                else
                {
                    current_texture = player_base.Alive_texture;
                }
            }

            if (Game1.mouse_state.X > (Game1.resolution.X + player_base.Size.X) / 2)
            { facing_right = true; }
            else
            { facing_right = false; }
        }
        public void TakeDamage(int damage, int new_invuln_ticks) //causes player to lose health and applies immunity
        {
            if (immune_ticks_remaining <= 0) //checks if the player is immune from damage
            {
                health -= damage;
                immune_ticks_remaining = new_invuln_ticks;
            }
        }
        public void RegenHealth() //regenerates player health up to maximum based on regen per level attribute
        {
            health = Math.Min(player_base.Max_health, health + player_base.Health_regen_per_level);
        }
        public void EquipWeapon(Weapon w)
        {
            current_weapon = w;
        }
        public void AddScore(int s)
        {
            score += s;
        }
        public void StopReloading()
        {
            reloading = false;
        }
        #endregion
    }
}
