﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class Projectile : Entity
    {
        #region FIELDS
        private Point start_location; //start location e.g. player
        private Point target; //end location e.g. cursor
        private float x_distance; //x distance between entity and cursor
        private float y_distance; //y distance between entity and cursor
        private int ticks_taken; //ticks since projectile was created
        private float shot_speed; //straight line speed of projectile when moving
        private int death_damage; //damage dealt during death animation
        private float target_distance; //total distance between entity and target

        private int damage_dealt; //amount of health enemies lose on collision with this
        private int collision_immune_ticks;
        
        public int Damage_dealt { get => damage_dealt; }
        public int Collision_immune_ticks { get => collision_immune_ticks; }
        #endregion

        #region PROCEDURES
        public Projectile(Point _start_location, Point _target, Weapon source_weapon, int spread_multiplier)
        {
            start_location = _start_location; //sets start and target point for projectile to move between
            target = _target;

            hitbox = new Rectangle(start_location, source_weapon.Weapon_base.Shot_size); //sets attributes based on the weapon the projectile was shot from
            shot_speed = source_weapon.Weapon_base.Shot_speed;
            current_texture = source_weapon.Weapon_base.Shot_texture;
            damage_dealt = source_weapon.Weapon_base.Shot_damage;
            death_size = source_weapon.Weapon_base.Shot_death_size;
            death_texture = source_weapon.Weapon_base.Shot_death_texture;
            death_duration = source_weapon.Weapon_base.Shot_death_duration;
            death_damage = source_weapon.Weapon_base.Shot_death_damage;
            collision_immune_ticks = source_weapon.Weapon_base.Shot_immune_ticks;

            SetTrajectory(spread_multiplier, source_weapon.Weapon_base.Shot_spread, source_weapon.Weapon_base.Shot_inaccuracy);
            ticks_taken = 0;
        }
        private void SetTrajectory(int spread_multiplier, float shot_spread, float shot_inaccuracy) //sets velocity and direction of projectile
        {
            x_distance = target.X - start_location.X; //calculates distance between start and target
            y_distance = target.Y - start_location.Y;
            float spread = shot_spread * spread_multiplier; //calulates non-random weapon spread
            spread += (float)(Game1.random.NextDouble() - 0.5) * shot_inaccuracy; //adds random inaccuracy to shot
            target.X -= (int)(y_distance * spread); //adjusts target location based on spread + inaccuracy
            target.Y += (int)(x_distance * spread);
            x_distance = target.X - start_location.X; //calculates distance between start and new adjusted target
            y_distance = target.Y - start_location.Y;
            target_distance = (float)Math.Sqrt(x_distance * x_distance + y_distance * y_distance); //calculates straight line distance
            if (target == start_location) //prevents divide by zero exception
            { target.X += 1; }//this means projectiles will shoot to the right if the start is in the same location as the target
        }
        public override void Update()
        {
            if (shot_speed > 0) //moves projectile if it is moving
            {
                Point new_location; //current location of projectile found by interpolation between start and target
                new_location.X = start_location.X + (int)(ticks_taken * shot_speed * x_distance / target_distance); //this only works if the projectile's speed is constant
                new_location.Y = start_location.Y + (int)(ticks_taken * shot_speed * y_distance / target_distance);
                hitbox = new Rectangle(new_location.X, new_location.Y, Hitbox.Width, Hitbox.Height);
            }
            ticks_taken++;
            base.Update();
        }
        public override void Kill() //kills projectile a set amount of time before it is destroyed
        {
            if (Alive)
            {
                shot_speed = 0;
                damage_dealt = death_damage;
            }
            base.Kill();
        }
        #endregion
    }
}
