﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class WeaponBase //contains information about one type of weapon
    {
        #region FIELDS
        private readonly string name; //weapon name
        private readonly Weapon.WeaponType type; //type of weapon, adjusts properties such as damage dealt
        private readonly Texture2D gun_texture; //texture used to display weapon pickup
        private readonly Point gun_size; //size of weapon texture
        private readonly int shot_damage; //entity health lost on collision with shot
        private readonly int shot_death_damage; //amount of damage dealt when explosion collides with entity
        private readonly int shot_death_duration; //amount of time an explosion lasts
        private readonly int shot_delay; //time in milliseconds between shots
        private readonly int max_ammo; //number of shots before reloading
        private readonly int reload_time; //time in milliseconds to reload
        private readonly bool automatic; //determines whether the fire button can be held down to shoot
        private readonly int shot_count; //number of projectiles created per shot (in an arc)
        private readonly float shot_speed; //speed of projectile per update
        private readonly float shot_spread; //seperation of projectiles in an arc
        private readonly float shot_inaccuracy; //randomly changes the bullets trajectory
        private readonly Point shot_size; //size of projectile texture
        private readonly Point shot_death_size; //size of explosion texture
        private readonly Texture2D shot_texture; //texture of projectile
        private readonly Texture2D shot_death_texture; //texture of projectile explosion
        private readonly bool drops_in_level; //determines if the weapon can be found on the floor in a level
        private readonly int score_to_drop; //the number of points the player needs for the weapon to appear in a level
        private readonly int shot_immune_ticks = 20; //length of time a bullet will make the player immune for

        public string Name => name;
        public Weapon.WeaponType Type => type;
        public Texture2D Gun_texture => gun_texture;
        public Point Gun_size => gun_size;
        public int Shot_damage => shot_damage;
        public int Shot_death_damage => shot_death_damage;
        public int Shot_death_duration => shot_death_duration;
        public int Shot_delay => shot_delay;
        public int Max_ammo => max_ammo;
        public int Reload_time => reload_time;
        public bool Automatic => automatic;
        public int Shot_count => shot_count;
        public float Shot_speed => shot_speed;
        public float Shot_spread => shot_spread;
        public float Shot_inaccuracy => shot_inaccuracy;
        public Point Shot_size => shot_size;
        public Point Shot_death_size => shot_death_size;
        public Texture2D Shot_texture => shot_texture;
        public Texture2D Shot_death_texture => shot_death_texture;
        public bool Drops_in_level => drops_in_level;
        public int Score_to_drop => score_to_drop;
        public int Shot_immune_ticks => shot_immune_ticks;
        #endregion

        #region CONSTRUCTOR
        public WeaponBase(List <string> file_line)
        {
            type = (Weapon.WeaponType)Convert.ToInt32(file_line[0]);
            name = file_line[1];
            gun_texture = Game1.content_loader.Load<Texture2D>(file_line[2]);
            gun_size = new Point(Convert.ToInt32(file_line[3]), Convert.ToInt32(file_line[4]));
            shot_damage = Convert.ToInt32(file_line[5]);
            shot_delay = Convert.ToInt32(file_line[6]);
            max_ammo = Convert.ToInt32(file_line[7]);
            reload_time = Convert.ToInt32(file_line[8]);
            automatic = Convert.ToBoolean(file_line[9]);
            shot_count = Convert.ToInt32(file_line[10]);
            shot_speed = Convert.ToSingle(file_line[11]);
            shot_spread = Convert.ToSingle(file_line[12]);
            shot_inaccuracy = Convert.ToSingle(file_line[13]);
            shot_texture = Game1.content_loader.Load<Texture2D>(file_line[14]);
            shot_size = new Point(Convert.ToInt32(file_line[15]), Convert.ToInt32(file_line[16]));
            shot_death_texture = Game1.content_loader.Load<Texture2D>(file_line[17]);
            shot_death_size = new Point(Convert.ToInt32(file_line[18]), Convert.ToInt32(file_line[19]));
            shot_death_damage = Convert.ToInt32(file_line[20]);
            shot_death_duration = Convert.ToInt32(file_line[21]);
            drops_in_level = Convert.ToBoolean(file_line[22]);
            score_to_drop = Convert.ToInt32(file_line[23]);
            shot_immune_ticks = Convert.ToInt32(file_line[24]);
        }
        #endregion
    }
}
