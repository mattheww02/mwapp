﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.IO;

namespace A_Level_Project_1._4
{
    public class Room //contains a grid of tiles to be put in a room
    {
        #region FIELDS
        public enum PathDirection //location of room in relation to previously generated room
        {
            none,
            up,
            down,
            left,
            right
        }
        private const int width = 7;
        private const int height = 7;
        private readonly int[,] grid;
        private readonly PathDirection path_direction;

        public int[,] Grid { get => grid; }
        public PathDirection Path_direction { get => path_direction; }
        #endregion

        #region CONSTRUCTOR

        public Room(string file_name)
        {
            StreamReader reader;
            string current_line;
            grid = new int[width, height];
            file_name = Game1.content_loader.RootDirectory + file_name;
            try
            {
                reader = new StreamReader(file_name); //loads file for next room
                path_direction = (Room.PathDirection)Convert.ToInt32(reader.ReadLine()); //gets direction of room from file
                for (int y = 0; y < width; y++) //sets tiles in room from file
                {
                    current_line = reader.ReadLine();
                    for (int x = 0; x < height; x++)
                    {
                        grid[x, y] = Convert.ToInt32(Convert.ToString(current_line[x])); //casting used to give actual value instead of Unicode value
                    }
                }
                reader.Close();
            }
            catch (FileNotFoundException)
            { Game1.game_state = Game1.GameState.game_error; }
            catch (DirectoryNotFoundException)
            { Game1.game_state = Game1.GameState.game_error; }
        }
        #endregion
    }
}
