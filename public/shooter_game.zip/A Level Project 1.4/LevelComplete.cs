﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.IO;

namespace A_Level_Project_1._4
{
    public class LevelComplete //screen displayed when the player finishes a level, gives player score based on time taken
    {
        #region FIELDS
        private const Keys start_key = Keys.Space;
        private const string background_texture_file_name = "interface/level_complete";
        private readonly Texture2D background_texture;
        #endregion

        #region PROCEDURES
        public LevelComplete(ref Player player_char, long time_elapsed, ref int level_number)
        {
            try
            {
                background_texture = Game1.content_loader.Load<Texture2D>(background_texture_file_name);
            }
            catch (FileNotFoundException)
            {
                Game1.game_state = Game1.GameState.game_error;
            }
            level_number++; //increments level number to increase difficulty
            UpdateScore(ref player_char, time_elapsed, level_number);
        }

        private void UpdateScore(ref Player player_char, long time_elapsed, int level_number) //the player gains some points based on how long it took to complete the level
        {
            const int max_time_taken_base = 7500; //amount of time to complete a level
            const int max_time_taken_multiplier = 2500; //amount of extra time to complete each level as level number increases
            const int level_completion_score = 500; //score gained upon completing a level
            const float time_score_multiplier = 0.08f; //amount of score given based on time taken
            long max_time_taken = max_time_taken_base + level_number * max_time_taken_multiplier; //after this amount of time in a level, no points are gained for time taken
            int time_taken_score = (int)(Math.Max(0, max_time_taken - time_elapsed) * time_score_multiplier); //score gained for completing a level
            player_char.AddScore(level_completion_score + time_taken_score);
        }
        public void Update()
        {
            if (Game1.key_state.IsKeyDown(start_key) && Game1.old_key_state.IsKeyUp(start_key)) //next level is started
            { Game1.game_state = Game1.GameState.playing; }
        }
        public void Draw(SpriteBatch sprite_batch)
        {
            sprite_batch.Draw(background_texture, new Rectangle(0, 0, Game1.resolution.X, Game1.resolution.Y), Color.White);
        }
        #endregion
    }
}
