﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.IO;

namespace A_Level_Project_1._4
{
    public class Level //contains information about the current level being played and the entities in it
    {
        #region FIELDS
        private const string wall_texture_file_name = "level_tiles/wall_05_big"; //file name of textures and fonts used in level
        private const string ground_texture_file_name = "level_tiles/ground_05_big";
        private const string wall_top_texture_file_name = "level_tiles/wall_05_top";
        private const string wall_bottom_texture_file_name = "level_tiles/wall_05_bottom";
        private const string wall_left_texture_file_name = "level_tiles/wall_05_left";
        private const string wall_right_texture_file_name = "level_tiles/wall_05_right";
        private const string full_health_texture_file_name = "health_bar_full";
        private const string empty_health_texture_file_name = "health_bar_empty";
        private const string full_ammo_texture_file_name = "interface/ammo_bar_full";
        private const string empty_ammo_texture_file_name = "interface/ammo_bar_empty";
        private const string weapon_pickup_font_file_name = "weapon_pickup_font";
        private const string hud_font_file_name = "health_font";
        private const string hud_reloading_text = "RELOADING..."; //text shown on screen for each interface element
        private const string hud_ammo_text = "AMMO: ";
        private const string hud_health_text = "HEALTH: ";
        private const string hud_score_text = "SCORE: ";
        private const string hud_time_text = "TIME: ";
        private const string hud_enemy_count_text = "ENEMIES: ";
        private const string hud_fraction_text = "/";
        private const string hud_format_long = "D6"; //string format used to display some interface elements
        private const string hud_format_short = "D4";

        private const float animation_speed = 0.17f; //speed animations play at
        private const float hud_weapon_scale = 2.0f; //scale of weapon type interface element
        private const float player_weapon_scale = 1.25f; //scale of weapon held by player character
        private const int hud_time_divisor = 6; //number of game ticks needed to increment time on HUD
        private const int player_weapon_right_offset = 25; //offset of weapon from player when facing right
        private const int player_weapon_left_offset = -15; //weapon offset when facing left
        private const int player_weapon_vertical_offset = 15; //vertical offset of weapon from player
        private const int draw_distance_x = 16; //tiles won't draw if further from the player than this to save processor time
        private const int draw_distance_y = 10;
        private const int safe_radius = 8; //distance enemies and weapons can begin to spawn away from the player
        private const int max_text_age = 50; //the amount of time the weapon's name will display on screen after pick up
        private const int tile_width = 64; //scale of tiles on screen
        private const int tile_height = 64;
        private const int grid_width = 240; //size of map including outside areas (i.e. walls)
        private const int grid_height = 240;
        private const int start_enemy_base = 15; //starting number of enemies for level 1
        private const int start_enemy_multiplier = 2; //rate at which start enemy count increases each level
        private const Keys player_pickup_key = Keys.E; //key used for player to pick up weapon from ground

        private readonly string[] room_file_names; //file names of rooms to load for this level
        private readonly Point room_size = new Point(7, 7); //size of each modular room in the level
        private readonly Point hud_ammo_bar_location = new Point(50, 100); //location of interface elements
        private readonly Point hud_health_bar_location = new Point(50, 50);
        private readonly Point hud_weapon_location = new Point(50, 150);
        private readonly Vector2 hud_ammo_text_location = new Vector2(63, 116);
        private readonly Vector2 hud_health_text_location = new Vector2(63, 62);
        private readonly Vector2 hud_score_text_location = new Vector2(1500, 50);
        private readonly Vector2 hud_time_text_location = new Vector2(1500, 85);
        private readonly Vector2 hud_enemy_count_location = new Vector2(1500, 120);

        private long time_elapsed; //amount of time since start of level
        private int start_enemy_count; //number of enemies that are generated at the start of the level
        private int weapon_pickup_text_age; //the amount of time since the player picked up the weapon
        private string weapon_pickup_text_string; //string shown on screen to indicate weapon that can be picked up
        private bool[,,] wall_edges; //3D array to store where wall edges should be displayed
        private int[,] grid; //stores all the tiles in the level (represented as integers) 
        private Vector2 weapon_pickup_text_location; //location in level of weapon text
        private Point camera_location; //camera shows perspective of player (follows player's character)
        private Point camera_offset; //puts the player's character in the middle of the screen
        private SpriteFont hud_font; //font used by HUD elements
        private SpriteFont weapon_pickup_font; //font used to display weapon name when picked up
        private Texture2D full_health_texture;
        private Texture2D empty_health_texture;
        private Texture2D full_ammo_texture;
        private Texture2D empty_ammo_texture;
        private Texture2D[] wall_edge_textures; //textures used for the edges of walls
        private Player player1; //entity controlled by player
        private List<Projectile> player_projectiles; //projectiles created by the player
        private List<Enemy> enemies; //list of all living enemies in the level
        private List<Projectile> enemy_projectiles; //projectiles created by enemies
        private List<Weapon> weapon_pickups; //weapons found on floor
        private List<Node> nodes; //adjacency list for enemy pathfinding   
        private List <Room> level_rooms; //modular rooms connected together to make the level
        private Dictionary<int, Tile> tile_list; //a dictionary mapping values in the level grid to tiles
        private Dictionary<Enemy.EnemyType, EnemyBase> enemy_templates;
        private Dictionary<Weapon.WeaponType, WeaponBase> weapon_templates;

        public long Time_elapsed { get => time_elapsed; }
        #endregion

        #region CONSTRUCTOR
        public Level(int level_number, ref Player _player1, ref Dictionary<Enemy.EnemyType, EnemyBase> _enemy_templates, ref Dictionary<Weapon.WeaponType, WeaponBase> _weapon_templates, LevelTemplate level_template)
        {
            try
            {
                tile_list = new Dictionary<int, Tile>(); //tile dictionary contains reference to every type of tile in a level (potentially this could be loaded from a file if more than 2 tile types were used)
                tile_list.Add(0, new Tile(level_template.level_texture_file_names[0], true)); //wall tile
                tile_list.Add(1, new Tile(level_template.level_texture_file_names[1], false)); //floor tile
                Texture2D wall_top_texture = Game1.content_loader.Load<Texture2D>(level_template.level_texture_file_names[2]); //loads wall edge textures
                Texture2D wall_bottom_texture = Game1.content_loader.Load<Texture2D>(level_template.level_texture_file_names[3]);
                Texture2D wall_left_texture = Game1.content_loader.Load<Texture2D>(level_template.level_texture_file_names[4]);
                Texture2D wall_right_texture = Game1.content_loader.Load<Texture2D>(level_template.level_texture_file_names[5]);
                Texture2D wall_top_left_texture = Game1.content_loader.Load<Texture2D>(level_template.level_texture_file_names[6]);
                Texture2D wall_top_right_texture = Game1.content_loader.Load<Texture2D>(level_template.level_texture_file_names[7]);
                wall_edge_textures = new Texture2D[] { wall_top_texture, wall_bottom_texture, wall_left_texture, wall_right_texture, wall_top_left_texture, wall_top_right_texture };
                wall_edges = new bool[grid_width, grid_height, wall_edge_textures.Count()];

                full_health_texture = Game1.content_loader.Load<Texture2D>(full_health_texture_file_name);
                empty_health_texture = Game1.content_loader.Load<Texture2D>(empty_health_texture_file_name);
                full_ammo_texture = Game1.content_loader.Load<Texture2D>(full_ammo_texture_file_name);
                empty_ammo_texture = Game1.content_loader.Load<Texture2D>(empty_ammo_texture_file_name);
                hud_font = Game1.content_loader.Load<SpriteFont>(hud_font_file_name);
                weapon_pickup_font = Game1.content_loader.Load<SpriteFont>(weapon_pickup_font_file_name);
            }
            catch (FileNotFoundException)
            {
                Game1.game_state = Game1.GameState.game_error;
            }
            catch (DirectoryNotFoundException)
            {
                Game1.game_state = Game1.GameState.game_error;
            }
            player_projectiles = new List<Projectile>();
            enemy_projectiles = new List<Projectile>();
            weapon_pickups = new List<Weapon>();
            enemies = new List<Enemy>();
            grid = new int[grid_width, grid_height];
            camera_offset = new Point(-Game1.resolution.X / 2, -Game1.resolution.Y / 2); //makes the player appear in the middle of the screen
            enemy_templates = _enemy_templates;
            weapon_templates = _weapon_templates;
            player1 = _player1;
            player1.RegenHealth();
            player1.Current_weapon.RefillAmmo(); 
            start_enemy_count = (int)(start_enemy_base * (int)Math.Pow(start_enemy_multiplier, level_number - 1) * player1.Start_enemy_multiplier); //calculates starting number of enemies for the level
            weapon_pickup_text_string = "";
            weapon_pickup_text_location = new Vector2(0, 0);
            weapon_pickup_text_age = 0;
            time_elapsed = 0;
            room_file_names = level_template.room_file_names;
            LoadRooms(); //loads modular rooms which can be combined into a level
            if (Game1.game_state == Game1.GameState.playing) //level will only generate if all files are loaded correctly
            {
                GenerateLevel();
                MakeNodes(); //generates the level's adjacency list
                GenerateWalls(); //generates wall edge array
                GenerateEnemies(start_enemy_count, safe_radius, level_template.enemy_amounts); //places enemies in random valid locations
                GenerateWeapons(safe_radius); //places weapons on paths
            } 
        }
        #endregion

        #region ENEMY PATHFINDING
        private void MakeNodes() //generates a list of nodes to be used for pathfinding
        { //sets nodes to be the middle of each room and adds them to a list
            const int path_length = 5; //the length of corridors in the level
            nodes = new List<Node>();
            Point top_left = new Point((grid_width / 2 + 1) - (int)Math.Floor((decimal)(grid_width / (path_length * 2))) * path_length,
                (grid_height / 2 + 1) - (int)Math.Floor((decimal)(grid_height / (path_length * 2))) * path_length); //top-left-most possible node

            for (int y = top_left.Y; y < grid_height; y += path_length) //checks each possible node location in the level grid
            {
                for (int x = top_left.X; x < grid_width; x += path_length)
                {
                    if (!tile_list[grid[x, y]].Solid) //checks to see if each node is on a path tile
                    {
                        nodes.Add(new Node(x * tile_width, y * tile_height)); //adds a new node
                    }
                }
            }
            ConnectNodes();
        }
        private void ConnectNodes() //connects nodes in the pathfinding graph
        {
            const int max_connection_length = 500; //the longest edge length allowed between 2 nodes
            foreach (Node p1 in nodes)
            {
                foreach (Node p2 in nodes)
                {
                    if (p1.Location.X == p2.Location.X || p1.Location.Y == p2.Location.Y) //diagonals don't need to be checked due to the design of the level
                    {
                        if (CheckPathClear(p1.Location, p2.Location) &&
                        GetDistance(p1.Location, p2.Location) < max_connection_length)
                        { //connects 2 nodes if there is no wall between them and they are close enough
                            p1.Adj.Add(p2);
                            p2.Adj.Add(p1);
                        }
                    }
                }
            }
        }
        private Stack<Node> MakeNodeStack(Point enemy_location) //finds a stack of nodes for the enemy to follow 
        {
            Queue<Node> node_queue = new Queue<Node>(); //records which nodes need to be checked
            bool[] visited = new bool[nodes.Count()]; //records which nodes have been visited
            int[] parent = new int[nodes.Count()]; //records the parent node of each node
            int start = ClosestNode(nodes, enemy_location); //starting location of the enemy
            int target = ClosestNode(nodes, player1.Hitbox.Location); //location of the player/target

            for (int i = 0; i < visited.Length; i++) //initialises array
            {
                visited[i] = false; //sets all values in the array to false (no points have been visted yet)
                parent[i] = -1; //no nodes have parents yet
            }
            visited[start] = true;
            node_queue.Enqueue(nodes[start]);

            while (node_queue.Count > 0 && !visited[target]) //while target not found (unless a target can't be found)
            {
                Node v = node_queue.Dequeue(); //gets the next node from the queue to check
                foreach (Node u in v.Adj) //looks at its neighbours
                {
                    if (!visited[nodes.IndexOf(u)])
                    {
                        node_queue.Enqueue(u); //adds unvisited nodes to the node queue to be checked
                        visited[nodes.IndexOf(u)] = true;
                        parent[nodes.IndexOf(u)] = nodes.IndexOf(v); //sets parent of unvisited adjacent nodes to be the current node in the queue
                    }
                }
            }

            Stack<Node> node_stack = new Stack<Node>();
            Node current_node = nodes[target];
            node_stack.Push(current_node);
            while (!node_stack.Contains(nodes[start])) //adds paths in the route to a stack
            { //target node will be at the bottom of the stack, with start at the top
                current_node = nodes[parent[nodes.IndexOf(current_node)]];
                node_stack.Push(current_node);
            }
            return node_stack;
        }
        private int ClosestNode(List<Node> nodes, Point p) //finds the closest path to a given point
        {
            int closest = 0;
            int closest_distance = (int)GetDistance(p, nodes[0].Location); //int is precise enough for this function
            int current_distance;
            for (int i = 1; i < nodes.Count; i++) //checks every node and returns the closest node with no wall blocking the path
            {
                current_distance = (int)GetDistance(p, nodes[i].Location);
                if (current_distance < closest_distance &&
                    CheckPathClear(p, nodes[i].Location))
                {
                    closest = i;
                    closest_distance = current_distance;
                }
            }
            return closest;
        }
        public bool CheckPathClear(Point start, Point end)//checks if the direct path between two points is clear of walls
        {
            const float check_interval = 0.5f; //determines how many checks are done between the two points - smaller is more accurate
            Point a = new Point(start.X / tile_width, start.Y / tile_height); //the coordinates in the level grid of the start point
            Point b = new Point(end.X / tile_width, end.Y / tile_width); //coordinates of the end point

            if (a.X - b.X != 0)
            {
                if (a.X > b.X) //sets a to be the point on the left
                {
                    Point c = a;
                    a = b;
                    b = c;
                }
                float gradient = (b.Y - a.Y) / (b.X - a.X); //gets gradient between a and b
                for (float x = a.X; x <= b.X; x += check_interval)
                {
                    if (tile_list[grid[(int)x, (int)(a.Y + ((int)x - a.X) * gradient)]].Solid) //checks each tile on the line between a and b
                    { return false; }
                }
            }
            else //this happens if change in x is 0 to avoid a divide by zero exception
            {
                if (a.Y > b.Y) //sets a to be the top point
                {
                    Point c = a;
                    a = b;
                    b = c;
                }
                for (int y = a.Y; y <= b.Y; y++) //small check interval not needed here because the line is vertical and will overlap every tile
                {
                    if (tile_list[grid[a.X, y]].Solid) //checks each tile on the line between a and b
                    { return false; }
                }
            }
            return true;
        }
        #endregion

        #region LEVEL GENERATION
        private void LoadRooms() //loads room files and stores them as an array
        {
            level_rooms = new List<Room>();
            foreach (string s in room_file_names)
            {
                level_rooms.Add(new Room(s));
            }
        }
        private void GenerateLevel() //procedurally generates an array of integers which can be used as a level
        {
            const int map_size = 50; //number of rooms in the level
            const int path_length = 5; //distance between two adjacent rooms
            const int half_path_length = 3;
            Random r = Game1.random;
            Point start_point = new Point(grid_width / 2 + 1, grid_height / 2 + 1); //the player and the level generation start in the middle of the grid
            Point current_point = start_point;
            int random_index;

            GenerateRoom(current_point, 0);
            for (int i = 1; i < map_size; i++)
            {
                random_index = r.Next(1, level_rooms.Count()); //the first room is the start room - it can't be placed anywhere else in the level
                switch (level_rooms[random_index].Path_direction) //makes a corridor in a random direction
                { //each case checks that there isn't already a corridor there and that the edge of the level hasn't been reached
                    case Room.PathDirection.up: //make a corridor going up
                        if (current_point.Y - path_length > half_path_length)
                        { current_point.Y -= path_length; }
                        break;
                    case Room.PathDirection.down: //corridor going down
                        if (current_point.Y + path_length < grid.GetLength(1) - 3)
                        { current_point.Y += path_length; }
                        break;
                    case Room.PathDirection.left: //corridor going left
                        if (current_point.X - path_length > half_path_length)
                        { current_point.X -= path_length; }
                        break;
                    case Room.PathDirection.right: //corridor going right
                        if (current_point.X + 5 < grid.GetLength(0) - half_path_length)
                        { current_point.X += path_length; }
                        break;
                }
                if (!tile_list[grid[current_point.X, current_point.Y]].Solid) //iteration not counted if a room was already in the same location
                { i--; }
                GenerateRoom(current_point, random_index); //generates room using given location and type
            }
            player1.SetLocation(start_point.X * tile_width, start_point.Y * tile_height); //sets player location to start
        }
        private void GenerateRoom(Point location, int room_index) //changes the level grid given a room type and location
        {
            int half_room_length = (int)Math.Floor((decimal)(room_size.X / 2));
            for (int y = 0; y < room_size.Y; y++) //checks every tile in the room against the corresponding level tile
            {
                for (int x = 0; x < room_size.X; x++)
                {
                    if (level_rooms[room_index].Grid[x, y] > grid[location.X + x - half_room_length, location.Y + y - half_room_length]) //tiles with a bigger index will overwrite lower indices
                    {
                        grid[location.X + x - half_room_length, location.Y + y - half_room_length] = level_rooms[room_index].Grid[x, y];
                    }
                }
            }
        }
        private void GenerateWalls() //checks which wall tiles in the grid should have wall edge textures
        {
            for (int y = 0; y < wall_edges.GetLength(1); y++)
            {
                for (int x = 0; x < wall_edges.GetLength(0); x++)
                {
                    if (y < grid.GetLength(1) - 1 && y > 0 && x < grid.GetLength(0) - 1 && x > 0 && tile_list[grid[x, y]].Solid) //checks every wall in the level
                    {
                        wall_edges[x, y, 0] = !tile_list[grid[x, y - 1]].Solid; //adds top and bottom wall borders on wall/floor edges
                        wall_edges[x, y, 1] = !tile_list[grid[x, y + 1]].Solid;
                        if (wall_edges[x,y,1]) //if the wall has a bottom border, it can't have a left or right border
                        {
                            wall_edges[x, y, 2] = false;
                            wall_edges[x, y, 3] = false;
                        }
                        else if (wall_edges[x, y, 0])
                        {
                            wall_edges[x, y, 2] = !tile_list[grid[x - 1, y]].Solid;
                            wall_edges[x, y, 3] = !tile_list[grid[x + 1, y]].Solid;
                        }
                        else
                        {
                            wall_edges[x, y, 2] = !tile_list[grid[x - 1, y]].Solid || !tile_list[grid[x - 1, y + 1]].Solid;
                            wall_edges[x, y, 3] = !tile_list[grid[x + 1, y]].Solid || !tile_list[grid[x + 1, y + 1]].Solid;
                            wall_edges[x, y, 4] = !tile_list[grid[x - 1, y - 1]].Solid &!wall_edges[x, y, 2];
                            wall_edges[x, y, 5] = !tile_list[grid[x + 1, y - 1]].Solid &!wall_edges[x, y, 3];
                        }
                    }  //adds border around walls (only used to make the game look nicer)
                }
            }
        }   
        private void GenerateEnemies(int start_enemy_count, int player_safe_zone_radius, float[] enemy_amounts) //creates enemies on paths in the level
        {
            const int max_allowed_enemies = 1920; //most enemies that are allowed to start in a level
            start_enemy_count = Math.Min(start_enemy_count, max_allowed_enemies);
            player_safe_zone_radius *= tile_width;
            Random r = new Random();
            int random_node, new_enemy_type;
            
            Enemy new_enemy;
            for (int i = 1; i <= start_enemy_count; i++)
            {
                random_node = r.Next(0, nodes.Count());
                if (GetDistance(player1.Hitbox.Location, nodes[random_node].Location) > player_safe_zone_radius)
                {
                    float rf;
                    rf = enemy_amounts.Sum() * (float)r.NextDouble(); //gets a random float between 0 and the sum of the enemy 'rarities'
                    for (new_enemy_type = 0; rf > 0; new_enemy_type++) //subtracts enemy rarity from random float until random float is less than 0
                    {
                        rf -= enemy_amounts[new_enemy_type];
                    }
                    new_enemy_type--;
                    new_enemy = new Enemy((Enemy.EnemyType)new_enemy_type, ref enemy_templates, ref weapon_templates); //generated random number represents a random enemy type
                    new_enemy.SetLocation(nodes[random_node].Location); //sets location of enemy to chosen random location
                    enemies.Add(new_enemy);
                }
                else
                { i--; }
            }
        }
        public float GetDistance(Point p1, Point p2) //returns straight line distance between 2 points
        {
            return (float)Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2));
        }
        private void GenerateWeapons(int player_safe_zone_radius) //creates weapons to pick up on paths in the level
        {
            List<Weapon.WeaponType> weapon_types = new List<Weapon.WeaponType>(); //a list of all types of weapons to be placed
            Random r = Game1.random;
            int rx, ry;
            player_safe_zone_radius *= tile_width;
            foreach (WeaponBase w in weapon_templates.Values)
            {
                if (w.Drops_in_level && w.Score_to_drop <= player1.Score && player1.Current_weapon.Weapon_base.Type != w.Type)
                { weapon_types.Add(w.Type); } //checks each weapon type to see if it should be in the level
            }
            for (int i = 0; i<weapon_types.Count(); i++) //puts each weapon in a different location in the level
            {
                rx = r.Next(0, grid.GetLength(0)); //gets random location in grid
                ry = r.Next(0, grid.GetLength(1));
                if (!tile_list[grid[rx, ry]].Solid && GetDistance(player1.Hitbox.Location, new Point(rx * tile_width, ry * tile_height)) > player_safe_zone_radius && !WeaponOnTile(rx, ry))
                { //checks that the random location chosen is allowed
                    weapon_pickups.Add(new Weapon(weapon_types[i], ref weapon_templates));
                    weapon_pickups.Last().Gun_location = new Point(rx * tile_width, ry * tile_height);
                }
                else
                { i--; } //tries again if location is invalid
            }
        }
        private bool WeaponOnTile(int x, int y) //checks if there is already a weapon on a given tile
        {
            foreach (Weapon w in weapon_pickups)
            {
                if (w.Gun_location.X / tile_width == x && w.Gun_location.Y / tile_height == y)
                { return true; }
            }
            return false;
        }
        #endregion

        #region ENTITY UPDATING
        public void Update(GameTime game_time) //updates each part of the level
        {
            UpdatePlayer(game_time);
            UpdateProjectiles();
            UpdateEnemies(game_time);
            UpdatePickups();
            time_elapsed++;
        }
        private void UpdatePlayer(GameTime game_time) //updates player movement and weapon
        {
            int time_ms = (int)game_time.TotalGameTime.TotalMilliseconds; //game time in milliseconds
            if (player1.Health <= 0) //checks if the player should be alive
            {
                player1.Kill();
                if (player1.Dead_ticks >= player1.Death_duration) //checks how long the player has been dead
                {
                    Game1.game_state = Game1.GameState.game_over;
                }
            }
            player1.Update(game_time); //updates player's velocity
            MoveEntity(player1); //moves player based on its velocity
            camera_location = new Point(player1.Hitbox.X + camera_offset.X, player1.Hitbox.Y + camera_offset.Y); //updates camera location

            if (player1.Shooting && player1.Current_weapon.FinishedShooting(time_ms) && !player1.Reloading && player1.Alive)

            { //checks if the player is shooting and if its weapon can shoot
                AddProjectile(player1.Current_weapon, player1.Hitbox, Game1.mouse_state.Position, false);
                player1.Current_weapon.Shoot(time_ms);
            }
            if (player1.Reloading && player1.Current_weapon.FinishedReload(time_ms))
            { //checks if player is reloading and if reloading is finished
                player1.Current_weapon.RefillAmmo();
                player1.StopReloading();
            }
        }
        private void UpdateProjectiles() //updates player and enemy projectiles
        {
            foreach (Projectile p in player_projectiles) //updates and moves all player's projectiles
            {
                p.Update();
            }
            foreach (Projectile p in enemy_projectiles) //updates and moves all enemies' projectiles
            {
                p.Update();
                if (p.Hitbox.Intersects(player1.Hitbox)) //damages player character if an enemy's projectile collides with it
                { player1.TakeDamage(p.Damage_dealt, p.Collision_immune_ticks); }
            }
            for (int i = player_projectiles.Count - 1; i >= 0; i--) //removes projectiles that collide with walls
            {
                if (CheckProjTileCollision(player_projectiles[i])) //displays a death animation and changes state of projectile
                { player_projectiles[i].Kill(); }
                if (player_projectiles[i].Dead_ticks >= player_projectiles[i].Death_duration) //removes projectile from game after it has been dead for its set death duration
                { player_projectiles.RemoveAt(i); }
            }
            for (int j = enemy_projectiles.Count - 1; j >= 0; j--) //repeated for enemy projectiles
            {
                if (CheckProjTileCollision(enemy_projectiles[j]))
                { enemy_projectiles[j].Kill(); }
                if (enemy_projectiles[j].Dead_ticks >= enemy_projectiles[j].Death_duration)
                { enemy_projectiles.RemoveAt(j); }
            }
        }
        private void UpdateEnemies(GameTime game_time) //updates movement and behaviour of enemies
        {
            int time_ms = (int)game_time.TotalGameTime.TotalMilliseconds; //game time in milliseconds
            if (enemies.Count() == 0) //level is completed when all enemies are dead
            { Game1.game_state = Game1.GameState.level_complete; }
            foreach (Enemy e in enemies)
            {
                if (e.Alive)
                {
                    if (e.Needs_new_path) //if an enemy requests a new path, a new stack of nodes to follow is generated
                    {
                        Stack<Node> track_paths = MakeNodeStack(e.Hitbox.Location);
                        e.Update(player1.Hitbox.Location, CheckPathClear(e.Hitbox.Location, player1.Hitbox.Location), track_paths);
                    }
                    else
                    { e.Update(player1.Hitbox.Location, CheckPathClear(e.Hitbox.Location, player1.Hitbox.Location)); }
                    MoveEntity(e);
                    for (int i = player_projectiles.Count - 1; i >= 0; i--) //checks for collision between enemy and player projectiles
                    {
                        if (e.Hitbox.Intersects(player_projectiles[i].Hitbox) && player_projectiles[i].Damage_dealt > 0)
                        {
                            e.TakeDamage(player_projectiles[i].Damage_dealt);
                            player_projectiles[i].Kill();
                        }
                    }
                    if (e.Hitbox.Intersects(player1.Hitbox)) //player takes damage when colliding with an enemy
                    { player1.TakeDamage(e.Collision_damage, e.Collision_immune_ticks); }

                    if (e.Current_weapon.Weapon_base.Type != Weapon.WeaponType.none) //checks that the enemy is holding a weapon
                    {
                        if (e.Current_weapon.FinishedShooting(time_ms) && GetDistance(e.Hitbox.Location, player1.Hitbox.Location) < e.Shoot_range 
                            && Game1.random.NextDouble() < e.Shoot_chance && CheckPathClear(e.Hitbox.Location, player1.Hitbox.Location))
                        { //enemies have a random chance of shooting if they can see the player
                            AddProjectile(e.Current_weapon, e.Hitbox, player1.Hitbox.Center, true);
                            e.Current_weapon.Shoot((int)game_time.TotalGameTime.TotalMilliseconds);
                        }
                    }
                } 
            }
            for (int j = enemies.Count - 1; j >= 0; j--) //checks if any enemies have died
            {
                if (enemies[j].Health <= 0)
                {
                    if (enemies[j].Alive)
                    {
                        player1.AddScore(enemies[j].Points_given);
                    }
                    enemies[j].Kill();
                }
                if (enemies[j].Dead_ticks >= enemies[j].Death_duration)
                {
                    enemies.RemoveAt(j);
                }
            }
        }
        private void UpdatePickups() //updates weapons found on the floor
        {
            if (weapon_pickup_text_age > max_text_age)
            {
                weapon_pickup_text_string = "";
            }
            for (int i = weapon_pickups.Count - 1; i >= 0; i--) //checks if the player can pick up a weapon, so its name can be displayed
            {
                if (player1.Hitbox.Intersects(new Rectangle(weapon_pickups[i].Gun_location, weapon_pickups[i].Weapon_base.Gun_size))) //if player is on top of a weapon on the ground
                {
                    if (weapon_pickup_text_age > max_text_age)
                    {
                        weapon_pickup_text_string = weapon_pickups[i].Weapon_base.Name.ToUpper() + "?";
                        weapon_pickup_text_location = new Vector2(weapon_pickups[i].Gun_location.X, weapon_pickups[i].Gun_location.Y);
                    }
                    if (Game1.key_state.IsKeyDown(player_pickup_key) && !Game1.old_key_state.IsKeyDown(player_pickup_key)) //checks if the player is trying to pick up a weapon
                    {
                        if (player1.Current_weapon.Weapon_base.Type != Weapon.WeaponType.none)
                        {
                            weapon_pickups.Add(player1.Current_weapon); //puts the player's previous weapon on the floor
                            weapon_pickups.Last().Gun_location = player1.Hitbox.Location;
                        }
                        weapon_pickup_text_string = weapon_pickups[i].Weapon_base.Name.ToUpper() + "!"; //displays the name of the weapon the player just picked up
                        player1.EquipWeapon(weapon_pickups[i]); //equips the new weapon
                        weapon_pickups.RemoveAt(i); //removes the weapon from the floor
                        weapon_pickup_text_age = 0;
                    }
                }
            }
            weapon_pickup_text_location = new Vector2(player1.Hitbox.Location.X, player1.Hitbox.Location.Y);
            weapon_pickup_text_age++;
        }
        private void AddProjectile(Weapon current_weapon, Rectangle entity_hitbox, Point target, bool is_enemy) //adds a projectile to the level
        {
            if (current_weapon.Weapon_base.Type != Weapon.WeaponType.none)
            {
                Point entity_middle = new Point(entity_hitbox.X + entity_hitbox.Width / 2 - current_weapon.Weapon_base.Shot_size.X / 2,
                    entity_hitbox.Y + entity_hitbox.Height / 2 - current_weapon.Weapon_base.Shot_size.Y / 2); //gets the middle of the entity's hitbox
                if (is_enemy)
                {
                    enemy_projectiles.Add(new Projectile(entity_middle, target, current_weapon, 0));
                }
                else
                {
                    target = new Point(target.X + camera_location.X - player1.Current_weapon.Weapon_base.Shot_size.X / 2,
                    target.Y + camera_location.Y - player1.Current_weapon.Weapon_base.Shot_size.Y / 2); //gets the correct location of the mouse cursor
                    player_projectiles.Add(new Projectile(entity_middle, target, current_weapon, 0));
                }
                if (current_weapon.Weapon_base.Shot_count > 1)//adds multiple projectiles for weapons with multiple projectiles
                {
                    for (int i = 2; i <= current_weapon.Weapon_base.Shot_count; i += 2)
                    {
                        for (int j = -1; j <= 1; j += 2) //adds a projectile to either side of the central projectile
                        {
                            if (is_enemy)
                            {
                                enemy_projectiles.Add(new Projectile(entity_middle, target, current_weapon, i * j));
                            }
                            else
                            {
                                player_projectiles.Add(new Projectile(entity_middle, target, current_weapon, i * j));
                            }
                        } //spread multiplier tells the projectile what angle to shoot at
                    }
                }
            }
        }
        #endregion

        #region COLLISION DETECTION
        private void MoveEntity(Entity entity) //moves an entity based on its velocity
        {
            bool x_collision = CheckEntityTileCollisionX(entity); //checks if entity has collided horizontally
            bool y_collision = CheckEntityTileCollisionY(entity); //checks if entity has collided vertically
            if (x_collision) //stops entity in x direction
            {
                entity.StopVelocity(true, false);
            }
            else //moves entity in x direction
            {
                entity.MoveHitbox((int)entity.Velocity.X, 0);
            }
            if (y_collision) //stops entity in y direction
            {
                entity.StopVelocity(false, true);
            }
            else //moves entity in y direction
            {
                entity.MoveHitbox(0, (int)entity.Velocity.Y);
            }
        }
        private bool CheckEntityTileCollisionX(Entity entity) //checks horizontal collision between an entity and a tile
        {
            if (entity.Velocity.X < 0) //moving left
            {
                for (int y = entity.Hitbox.Top / tile_height; y <= entity.Hitbox.Bottom / tile_height; y++)
                { //each tile from the current top left to the next bottom left is checked
                    for (int x = entity.Hitbox.Left / tile_width; x >= (entity.Hitbox.Left + entity.Velocity.X) / tile_width - 1; x--)
                    {
                        if (tile_list[grid[x, y]].Solid)
                        { return true; }
                    }
                }
            }
            else if (entity.Velocity.X > 0) //moving right
            {
                for (int y = entity.Hitbox.Top / tile_height; y <= entity.Hitbox.Bottom / tile_height; y++)
                { //tiles to the right are checked
                    for (int x = entity.Hitbox.Right / tile_width; x <= (entity.Hitbox.Right + entity.Velocity.X) / tile_width; x++)
                    {
                        if (tile_list[grid[x, y]].Solid)
                        { return true; }
                    }
                }
            }
            return false;
        }
        private bool CheckEntityTileCollisionY(Entity entity) //checks vertical collision between an entity and a tile
        {
            if (entity.Velocity.Y < 0) //moving up
            { //tiles above the player are checked
                for (int x = entity.Hitbox.Left / tile_height; x <= entity.Hitbox.Right / tile_height; x++)
                {
                    for (int y = entity.Hitbox.Top / tile_width; y >= (entity.Hitbox.Top + entity.Velocity.Y) / tile_width - 1; y--)
                    {
                        if (tile_list[grid[x, y]].Solid)
                        { return true; }
                    }
                }
            }
            else if (entity.Velocity.Y > 0) //moving down
            { //tiles below the player are checked
                for (int x = entity.Hitbox.Left / tile_height; x <= entity.Hitbox.Right / tile_height; x++)
                {
                    for (int y = entity.Hitbox.Bottom / tile_width; y <= (entity.Hitbox.Bottom + entity.Velocity.Y) / tile_width; y++)
                    {
                        if (tile_list[grid[x, y]].Solid)
                        { return true; }
                    }
                }
            }
            return false;
        }
        private bool CheckProjTileCollision(Projectile p) //checks collision between a projectile and a tile
        {
            Point top_left, top_right, bot_left, bot_right; //gets each corner of the projectile
            top_left = new Point(p.Hitbox.Left / tile_width, p.Hitbox.Top / tile_height);
            top_right = new Point(p.Hitbox.Right / tile_width, p.Hitbox.Top / tile_height);
            bot_left = new Point(p.Hitbox.Left / tile_width, p.Hitbox.Bottom / tile_height);
            bot_right = new Point(p.Hitbox.Right / tile_width, p.Hitbox.Bottom / tile_height);
            
            if (tile_list[grid[top_left.X, top_left.Y]].Solid || tile_list[grid[top_right.X, top_right.Y]].Solid || tile_list[grid[bot_left.X, bot_left.Y]].Solid || tile_list[grid[bot_right.X, bot_right.Y]].Solid)
            {  return true; } //returns true if any of the corners of the projectile have hit a wall
            return false;
        }
        #endregion

        #region LEVEL AND ENTITY DRAWING
        public void Draw(SpriteBatch sprite_batch) //everything in the level, including entities and interface, is drawn here
        {
            Point draw_top_left = new Point(Math.Max(0, player1.Hitbox.X / tile_width - draw_distance_x), Math.Max(0, player1.Hitbox.Y / tile_height - draw_distance_y)); //location of top left tile to be drawn (within draw distance)
            Point draw_bottom_right = new Point(Math.Min(grid.GetLength(0), player1.Hitbox.X / tile_width + draw_distance_x), Math.Min(grid.GetLength(1), player1.Hitbox.Y / tile_height + draw_distance_y)); //bottom right tile to be drawn
            for (int y = draw_top_left.Y; y < draw_bottom_right.Y; y++) //tiles are drawn in this nested for loop
            {
                for (int x = draw_top_left.X; x < draw_bottom_right.X; x++)
                {
                    sprite_batch.Draw(tile_list[grid[x, y]].Texture, new Rectangle(x * tile_width - camera_location.X, y * tile_height - camera_location.Y, tile_width, tile_height),
                        new Rectangle((x * tile_width) % tile_list[grid[x, y]].Texture.Width, (y * tile_height) % tile_list[grid[x, y]].Texture.Height, tile_width, tile_height), Color.White);
                    for (int z = 0; z < wall_edges.GetLength(2); z++)
                    {
                        if (wall_edges[x, y, z]) //draws wall edges on top of walls where needed
                        {
                            sprite_batch.Draw(wall_edge_textures[z], new Rectangle(x * tile_width - camera_location.X, y * tile_height - camera_location.Y, tile_width, tile_height),
                                new Rectangle((x * tile_width) % wall_edge_textures[z].Width, (y * tile_height) % wall_edge_textures[z].Height, tile_width, tile_height), Color.White);
                        }
                    }
                }
            }
            foreach (Weapon w in weapon_pickups) //draws all weapons that are on the ground
            {
                sprite_batch.Draw(w.Weapon_base.Gun_texture, new Rectangle(new Point(w.Gun_location.X - camera_location.X, w.Gun_location.Y - camera_location.Y), w.Weapon_base.Gun_size), Color.White);
            }
            foreach (Entity e in new List<Entity>().Concat(enemies).Concat(player_projectiles).Concat(enemy_projectiles)) //draws all entities on the screen
            {
                Point display_point = new Point(e.Hitbox.X - camera_location.X, e.Hitbox.Y - camera_location.Y); //point on screen that entity appears
                if (!(display_point.X < -e.Hitbox.Width || display_point.X > Game1.resolution.X || display_point.Y < -e.Hitbox.Height || display_point.Y > Game1.resolution.Y)) //checks that entity is within bounds of screen before drawing it
                {
                    if (e.Alive)
                    {
                        sprite_batch.Draw(e.Current_texture, new Rectangle(display_point, e.Hitbox.Size), new Rectangle((int)(time_elapsed * e.Hitbox.Width * animation_speed) % e.Current_texture.Width / e.Hitbox.Width * e.Hitbox.Width, 0, e.Hitbox.Width, e.Hitbox.Height), Color.White);
                    }
                    else
                    {
                        sprite_batch.Draw(e.Death_texture, new Rectangle(display_point, e.Hitbox.Size), new Rectangle(e.Dead_ticks * e.Current_texture.Width / e.Death_duration / e.Hitbox.Width * e.Hitbox.Width, 0, e.Hitbox.Width, e.Hitbox.Height), Color.White);
                    }
                }
            }
            SpriteEffects player_sprite_effect;
            if (player1.Facing_right) //player faces right if cursor is to the right of the player's character
            { player_sprite_effect = SpriteEffects.None; }
            else //makes the player character sprite face left
            { player_sprite_effect = SpriteEffects.FlipHorizontally; }
            Rectangle player_rectangle = new Rectangle(player1.Hitbox.X - camera_location.X, player1.Hitbox.Y - camera_location.Y, player1.Hitbox.Width, player1.Hitbox.Height);
            if (player1.Alive) //draws player
            {
                sprite_batch.Draw(player1.Current_texture, new Rectangle(new Point(player1.Hitbox.X - camera_location.X, player1.Hitbox.Y - camera_location.Y), player1.Hitbox.Size), 
                    new Rectangle((int)(time_elapsed * player1.Hitbox.Width * animation_speed) % player1.Current_texture.Width / player1.Hitbox.Width * player1.Hitbox.Width, 0, player1.Hitbox.Width, player1.Hitbox.Height), Color.White, 0.0f, new Vector2(0, 0), player_sprite_effect, 0.0f); //draws player
            }
            else
            {
                sprite_batch.Draw(player1.Death_texture, new Rectangle(new Point(player1.Hitbox.X - camera_location.X, player1.Hitbox.Y - camera_location.Y), player1.Hitbox.Size), new Rectangle(player1.Dead_ticks * player1.Current_texture.Width / player1.Death_duration / player1.Hitbox.Width * player1.Hitbox.Width, 0, player1.Hitbox.Width, player1.Hitbox.Height), Color.White);
            }
            sprite_batch.Draw(full_health_texture, new Rectangle(hud_health_bar_location.X, hud_health_bar_location.Y, empty_health_texture.Width * player1.Health / player1.Max_health, empty_health_texture.Height), Color.White); //draws player health
            if (player1.Reloading) //draws player ammo differently depending on whether the player is reloading a weapon
            { //draws ammo interface element when reloading
                sprite_batch.Draw(full_ammo_texture, new Rectangle(hud_ammo_bar_location.X, hud_ammo_bar_location.Y, (int)(empty_ammo_texture.Width * player1.Reload_percent), empty_health_texture.Height), Color.White);
                sprite_batch.DrawString(hud_font, hud_reloading_text, hud_ammo_text_location, Color.White);
            }
            else
            { //draws ammo interface element when not reloading
                sprite_batch.Draw(full_ammo_texture, new Rectangle(hud_ammo_bar_location.X, hud_ammo_bar_location.Y, empty_ammo_texture.Width * player1.Current_weapon.Current_ammo / player1.Current_weapon.Weapon_base.Max_ammo, empty_health_texture.Height), Color.White);
                sprite_batch.DrawString(hud_font, hud_ammo_text + player1.Current_weapon.Current_ammo + hud_fraction_text + player1.Current_weapon.Weapon_base.Max_ammo, hud_ammo_text_location, Color.White);
            }
            sprite_batch.Draw(empty_health_texture, new Rectangle(hud_health_bar_location.X, hud_health_bar_location.Y, empty_health_texture.Width, empty_health_texture.Height), Color.White); //draws border around health and ammo interface elements
            sprite_batch.Draw(empty_ammo_texture, new Rectangle(hud_ammo_bar_location.X, hud_ammo_bar_location.Y, empty_ammo_texture.Width, empty_ammo_texture.Height), Color.White);
            if (player1.Current_weapon.Weapon_base.Type != Weapon.WeaponType.none) //draws weapon type interface element (if a weapon is equipped)
            {
                Rectangle hud_weapon_rectangle = new Rectangle(hud_weapon_location, new Point((int)(player1.Current_weapon.Weapon_base.Gun_size.X * hud_weapon_scale), (int)(player1.Current_weapon.Weapon_base.Gun_size.X * hud_weapon_scale)));
                sprite_batch.Draw(player1.Current_weapon.Weapon_base.Gun_texture, hud_weapon_rectangle, Color.White);
            }
            if (weapon_pickup_text_age < max_text_age) //draws weapon pickup text
            {
                sprite_batch.DrawString(weapon_pickup_font, weapon_pickup_text_string, new Vector2(weapon_pickup_text_location.X - camera_location.X, weapon_pickup_text_location.Y - camera_location.Y), Color.White); //draws text showing weapon type of new weapon
            }
            else
            {
                sprite_batch.DrawString(weapon_pickup_font, weapon_pickup_text_string, new Vector2(weapon_pickup_text_location.X - camera_location.X, weapon_pickup_text_location.Y - camera_location.Y), Color.White); //draws text showing weapon type of weapon on floor
            }
            sprite_batch.DrawString(hud_font, hud_health_text + player1.Health + hud_fraction_text + player1.Max_health, hud_health_text_location, Color.White);
            sprite_batch.DrawString(hud_font, hud_score_text + player1.Score.ToString(hud_format_long), hud_score_text_location, Color.White);
            sprite_batch.DrawString(hud_font, hud_time_text + (time_elapsed / hud_time_divisor).ToString(hud_format_long), hud_time_text_location, Color.White);
            sprite_batch.DrawString(hud_font, hud_enemy_count_text + enemies.Count.ToString(hud_format_short), hud_enemy_count_location, Color.White);
        }
        #endregion
    }
}
