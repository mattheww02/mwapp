﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class Entity //contains information about objects in the level, entities inherit from this
    {
        #region FIELDS
        protected Texture2D current_texture; //texture used to display the entity
        protected Rectangle hitbox; //describes x and y position of entity, as well as scale
        protected Vector2 velocity; // direction and magnitude of movement per frame
        protected int death_duration; //amount of time between entity dying and entity being destroyed
        protected int dead_ticks; //amount of time since entity died
        protected Point death_size; //size of hitbox when dead
        protected Texture2D death_texture;
        protected Texture2D alive_texture;
        private bool alive; //whether entity is alive

        public Texture2D Current_texture { get => current_texture; }
        public Rectangle Hitbox { get => hitbox; }
        public Vector2 Velocity { get => velocity; }
        public int Death_duration { get => death_duration; }
        public int Dead_ticks { get => dead_ticks; }
        public Point Death_size { get => death_size; }
        public Texture2D Death_texture { get => death_texture; }
        public Texture2D Alive_texture { get => alive_texture; }
        public bool Alive { get => alive; }
        #endregion

        #region PROCEDURES
        public Entity()
        {
            velocity = new Vector2(0, 0);
            dead_ticks = -1;
            alive = true;
        }
        public virtual void Update()
        {
            if (!alive)
            {
                dead_ticks++;
            }
        }
        public virtual void Kill() //kills the entity so it can't do anything any more
        {
            if (alive) //if enemy wasn't already dead
            {
                alive = false;
                current_texture = death_texture;
                hitbox = new Rectangle(Hitbox.X + (Hitbox.Width - Death_size.X) / 2, Hitbox.Y + (Hitbox.Height - Death_size.Y) / 2,
                Death_size.X, Death_size.Y); //changes size of hitbox based on size of dead entity (e.g. if the entity explodes on death)
                velocity = new Vector2(0, 0); //stops movement of entity
            }
            dead_ticks++; //records the amount of time the entity has been dead
        }
        public void SetLocation(int x, int y) //sets hitbox location based on co ordinates
        {
            hitbox.X = x;
            hitbox.Y = y;
        }
        public void SetLocation(Point p) //sets hitbox location based on point
        {
            hitbox.X = p.X;
            hitbox.Y = p.Y;
        }
        public void MoveHitbox(int x, int y) //moves hitbox location
        {
            hitbox.X += x;
            hitbox.Y += y;
        }
        public void StopVelocity(bool x, bool y) //sets x and/or y velocity to 0
        {
            if (x)
            { velocity.X = 0; }
            if (y)
            { velocity.Y = 0; }
        }
        public void ChangeVelocity(float dx, float dy, float max) //changes velocity based on acceleration up to a max velocity
        {
            if (dx > 0) //moving right
            {
                velocity.X = Math.Min(max, velocity.X + dx);
            }
            else if (dx < 0) //moving left
            {
                velocity.X = Math.Max(-max, velocity.X + dx);
            }
            if (dy > 0) //moving down
            {
                velocity.Y = Math.Min(max, velocity.Y + dy);
            }
            else if (dy < 0) //moving up
            {
                velocity.Y = Math.Max(-max, velocity.Y + dy);
            }
        }
        #endregion
    }
}
