﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class Enemy : Entity
    {
        #region FIELDS
        public enum AttackType //types of movement AI an enemy can have
        {
            none,
            random,
            follow,
            track
        }
        public enum EnemyType //types of enemies in the game
        {
            robot,
            skeleton,
            plant
        }

        private const int ticks_for_dir_change = 20; //ticks until enemy changes direction when moving randomly
        private const int detect_range = 1000; //range at which enemy will look for a path if using 'track' movement type
        private const int reaction_time = 20; //time until node target changes after being in line of sight when using 'track' movement
        private const int hurt_duration = 4; //amount of time enemy will appear hurt after being attacked
        private const int points_given = 100; //points given to player on death
        private const int shoot_range = 400; //range at which enemy will try to shoot player
        private const float shoot_chance = 0.03f; //chance of shooting on any given update (if other criteria are met)

        private int current_dir = 0; //current direction of movement
        private int ticks_since_dir_change = 0; //time since enemy's direction has changed
        private int hurt_ticks = 0; //number of ticks enemy flashes red after being hurt
        private int stack_age = 0; //time since a new stack of nodes has been generated
        private int time_reacted = 0; //time since the enemy has detected the player
        private bool player_in_sight = false; //if player is in direct line of sight of the enemy
        private Point player_location;
        private Node path_target; //path closest to the target (the player)
        private Stack<Node> track_paths; //stack of nodes the enemy has to go to in order to reach the player

        private readonly EnemyBase enemy_base;
        private int health; //enemies with no health are removed from the game
        private Weapon current_weapon;
        private bool needs_new_path = false;

        public int Health { get => health; }
        public int Collision_damage { get => enemy_base.Collision_damage; }
        public int Collision_immune_ticks { get => enemy_base.Collision_immune_ticks; }
        public Weapon Current_weapon { get => current_weapon; }
        public bool Needs_new_path { get => needs_new_path; }
        public int Points_given { get => points_given; }
        public int Shoot_range { get => shoot_range; }
        public float Shoot_chance { get => shoot_chance; }
        #endregion

        #region CONSTRUCTOR
        public Enemy(EnemyType enemy_type, ref Dictionary<EnemyType, EnemyBase> enemy_templates, ref Dictionary<Weapon.WeaponType, WeaponBase> weapon_templates)
        {
            const int enemy_death_duration = 20;
            enemy_base = enemy_templates[enemy_type];
            death_size = enemy_base.Size;
            death_duration = enemy_death_duration;
            death_texture = enemy_base.Death_texture;
            alive_texture = enemy_base.Alive_texture;
            track_paths = new Stack<Node>();
            current_texture = enemy_base.Alive_texture;
            hitbox = new Rectangle(new Point(0, 0), enemy_base.Size);
            health = enemy_base.Max_health;
            current_weapon = new Weapon(enemy_base.Start_weapon_type, ref weapon_templates);
            if (enemy_base.Attack_type == AttackType.track)
            { path_target = new Node(Hitbox.X, Hitbox.Y); } //sets a new node as a temporary target to allow time for a path to be found
        }
        #endregion

        #region ENEMY UPDATING
        public void Update(Point _player_location, bool _player_in_sight, Stack<Node> _track_paths = null)
        {
            if (Alive)
            {
                player_location = _player_location;
                player_in_sight = _player_in_sight;
                switch (enemy_base.Attack_type)
                { //updates differently depending on AI type
                    case AttackType.random:
                        UpdateRandom();
                        break;
                    case AttackType.follow:
                        UpdateFollow();
                        break;
                    case AttackType.track:
                        if (needs_new_path) //if the enemy needs a new path, a path will have been generated for it in the Level class, then sent to this subroutine
                        {
                            track_paths = _track_paths;
                            needs_new_path = false;
                            stack_age = 0;
                            if (track_paths.Count() > 1) //removes the first node from the stack to stop enemies from going backwards when given a new stack
                            { track_paths.Pop(); }
                        }
                        UpdateTrack();
                        break;
                }
                if (hurt_ticks > 0) //if the enemy appears as damaged
                {
                    hurt_ticks--;
                    if (hurt_ticks == 0)
                    {
                        current_texture = alive_texture;
                    }
                }
            }
            base.Update();
        }
        private void UpdateRandom() //enemy moves in random directions
        {
            if (ticks_since_dir_change >= ticks_for_dir_change) //changes direction after a set amount of time
            {
                current_dir = Game1.random.Next(0, 5); //sets a new random direction
                ticks_since_dir_change = 0;
            }
            Move(current_dir, true);
            ticks_since_dir_change++;
        }
        private void UpdateFollow() //enemy moves in a straight line towards the player
        {
            if (GetDistance(player_location, Hitbox.Location) < detect_range && player_in_sight) //checks if straight path is clear and within range
            {
                MoveTo(player_location);
            }
            else
            { //if the player can't be found, the enemy will move randomly
                UpdateRandom();
            }
        }
        private void UpdateTrack() //uses a pathfinding algorithm to find the player
        {
            int distance_to_player = (int)GetDistance(player_location, Hitbox.Location);

            if (distance_to_player < detect_range && !player_in_sight)
            { //if the player is within range of the enemy but not in line of sight, the enemy will follow the stack of nodes
                time_reacted = 0;
                GoToPath();
            }
            else if (time_reacted < reaction_time) //enemies have a reaction time to prevent them getting stuck on walls
            { //if the player is in line of sight or out of range, but the enemy hasn't had enough time to react, it will follow its previous path
                time_reacted++;
                GoToPath();
            }
            else
            { //if the player is in line of sight or out of range, it will run towards the player (or move randomly if not in range)
                UpdateFollow();
            }
        }
        public void TakeDamage(int damage) //enemy loses health and appears hurt for a short duration
        {
            health -= damage;
            current_texture = enemy_base.Hurt_texture;
            hurt_ticks = hurt_duration;
        }
        #endregion

        #region MOVEMENT
        private void GoToPath() //enemy will go to the next node on the stack
        {
            const int target_distance = 100; //distance needed to change target
            const int max_stack_age = 100; //amount of time before a new stack of nodes should be generated (intensive processing)

            if (stack_age >= max_stack_age || track_paths.Count == 0)
            { //checks if a new stack should be generated
                needs_new_path = true;
            }
            if ((stack_age == 0 || GetDistance(Hitbox.Location, path_target.Location) < target_distance) 
                && track_paths.Count > 0)
            { //checks if the enemy is close enough to the node that it can go to the next one
                path_target = track_paths.Pop();
            }
            MoveTo(path_target.Location); //moves to the next node
            stack_age++;
        }
        private void MoveTo(Point target) //moves directly towards a target
        {
            if (target.Y < Hitbox.Y) //tries to match x and y values of enemy and target locations
            {
                Move(1, false);
            }
            else if (target.Y > Hitbox.Y)
            {
                Move(2, false);
            }
            if (target.X < Hitbox.X)
            {
                Move(3, false);
            }
            else if (target.X > Hitbox.X)
            {
                Move(4, false);
            }
        }
        private float GetDistance(Point a, Point b) //returns straight line distance between a and b
        {
            int w = a.X - b.X;
            int h = a.Y - b.Y;
            return (float)Math.Sqrt(w * w + h * h);
        }
        private void Move(int move_direction, bool decelerating) //accelerates/decelerates in a given direction
        {
            switch (move_direction)
            {
                case 0: //stops movement
                    if (decelerating)
                    {
                        ChangeVelocity(-enemy_base.Deceleration * Math.Sign(velocity.X), -enemy_base.Deceleration * Math.Sign(velocity.Y), 0);
                    }
                    break;
                case 1: //moves up
                    if (decelerating)
                    {
                        ChangeVelocity(-enemy_base.Deceleration * Math.Sign(velocity.X), 0, 0);
                    }
                    ChangeVelocity(0, -enemy_base.Deceleration, enemy_base.Max_speed);
                    break;
                case 2: //moves down
                    if (decelerating)
                    {
                        ChangeVelocity(-enemy_base.Deceleration * Math.Sign(velocity.X), 0, 0);
                    }
                    ChangeVelocity(0, enemy_base.Deceleration, enemy_base.Max_speed);
                    break;
                case 3: //moves left
                    if (decelerating)
                    {
                        ChangeVelocity(0, -enemy_base.Deceleration * Math.Sign(velocity.Y), 0);
                    }
                    ChangeVelocity(-enemy_base.Deceleration, 0, enemy_base.Max_speed);
                    break;
                case 4: //moves right
                    if (decelerating)
                    {
                        ChangeVelocity(0, -enemy_base.Deceleration * Math.Sign(velocity.Y), 0);
                    }
                    ChangeVelocity(enemy_base.Deceleration, 0, enemy_base.Max_speed);
                    break;
            }
        }
        #endregion
    }
}
