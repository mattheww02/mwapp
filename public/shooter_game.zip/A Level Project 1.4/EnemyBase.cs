﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class EnemyBase //related to enemies by composition, stores constant values for each enemy type
    {
        #region FIELDS
        private readonly string name; //enemy name
        private readonly Texture2D alive_texture; //texture shown when state of enemy is normal (not dead or hurt)
        private readonly Texture2D hurt_texture; //texture shown after enemy is damaged
        private readonly Texture2D death_texture; //texture shown when enemy is dead
        private readonly Point size; //hitbox size
        private readonly int max_health; //starting health
        private readonly float max_speed; //max vertical/horizontal speed
        private readonly float acceleration; //rate of acceleration when moving
        private readonly float deceleration;  //rate of deceleration when not accelerating in a given direction
        private readonly Enemy.AttackType attack_type; //type of behaviour used by enemy
        private readonly Weapon.WeaponType start_weapon_type; //type of weapon the enemy starts with
        private readonly int collision_damage; //damage given to player on collision
        private readonly int collision_immune_ticks; //amount of time the player is immune from damage after collision

        public string Name => name;
        public Texture2D Alive_texture => alive_texture;
        public Texture2D Hurt_texture => hurt_texture;
        public Texture2D Death_texture => death_texture;
        public Point Size => size;
        public int Max_health => max_health;
        public float Max_speed => max_speed;
        public float Acceleration => acceleration;
        public float Deceleration => deceleration;
        public Enemy.AttackType Attack_type => attack_type;
        public Weapon.WeaponType Start_weapon_type => start_weapon_type;
        public int Collision_damage => collision_damage;
        public int Collision_immune_ticks => collision_immune_ticks;
        #endregion

        #region CONSTRUCTOR
        public EnemyBase(List <string> file_line) //loads attributes from a line in a file
        {
            name = file_line[1];
            alive_texture = Game1.content_loader.Load<Texture2D>(file_line[2]);
            hurt_texture = Game1.content_loader.Load<Texture2D>(file_line[3]);
            death_texture = Game1.content_loader.Load<Texture2D>(file_line[4]);
            size = new Point(Convert.ToInt32(file_line[5]), Convert.ToInt32(file_line[6]));
            max_health = Convert.ToByte(file_line[7]);
            max_speed = Convert.ToSingle(file_line[8]);
            acceleration = Convert.ToSingle(file_line[9]);
            deceleration = Convert.ToSingle(file_line[10]);
            attack_type = (Enemy.AttackType)Convert.ToInt32(file_line[11]);
            start_weapon_type = (Weapon.WeaponType)Convert.ToInt32(file_line[12]);
            collision_damage = Convert.ToInt32(file_line[13]);
            collision_immune_ticks = Convert.ToInt32(file_line[14]);
        }
        #endregion
    }
}
