﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace A_Level_Project_1._4
{
    public class Node //a node used for enemy pathfinding
    {
        #region FIELDS
        private List<Node> adj; //all adjacent nodes which an enemy can travel directly to
        private Point location; //x and y coordinates of node in level

        public List<Node> Adj { get => adj; set => adj = value; }
        public Point Location { get => location; }
        #endregion

        #region CONSTRUCTOR
        public Node(int x, int y)
        {
            adj = new List<Node>();
            location = new Point(x, y);
        }
        #endregion
    }
}
